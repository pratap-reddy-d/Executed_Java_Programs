package com.nareshitjavaprgs;

import java.util.Scanner;
public class NetBill {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		double rupess = sc.nextDouble();
		double total;
		double discountamt;
		int discount;

		if(rupess < 5000 ) {
			discountamt = (rupess*5)/100;
			total = rupess-discountamt;
			discount = 5;
			
		}
		else if(rupess >= 5000 && rupess < 10000) {
			discountamt = (rupess*10)/100;
			total = rupess-discountamt;
			discount = 10;
		}
		else {
			discountamt = (rupess*15)/100;
			total = rupess-discountamt;
			discount = 15;
		}
		
		System.out.println("Discount is: "+ discount+"%");
		System.out.println("Discount Amount: "+ discountamt);
		System.out.println("Amount Payable: "+ total);
		
		sc.close();
	}

}
