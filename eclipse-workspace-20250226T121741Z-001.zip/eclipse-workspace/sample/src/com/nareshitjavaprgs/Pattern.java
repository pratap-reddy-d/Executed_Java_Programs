package com.nareshitjavaprgs;

public class Pattern {

	public static void main(String[] args) {
		for(int i = 0;i<5;i++) {
			for(int j=i;j<i;j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
	}
}
