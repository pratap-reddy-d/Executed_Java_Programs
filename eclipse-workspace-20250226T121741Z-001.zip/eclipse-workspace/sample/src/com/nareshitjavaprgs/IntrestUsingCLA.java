package com.nareshitjavaprgs;

public class IntrestUsingCLA {

	public static void main(String[] args) {
		
		int income = 990000;
		float taxRate = 4.9F;
		
		System.out.println("Taxable amount is: "+(income*taxRate/100));

	}
}
