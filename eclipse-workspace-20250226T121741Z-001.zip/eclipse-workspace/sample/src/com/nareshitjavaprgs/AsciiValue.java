package com.nareshitjavaprgs;

import java.util.Scanner;
public class AsciiValue {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
//		char ch = 'A';
		
	//	int val = ch;	
		
		
		String s1 = sc.next();
		
		char c1 = s1.charAt(0);
		
		
		int val1 = c1;
		
		
		
		System.out.println("The Ascii value of "+c1+" is " +val1 );
		
		System.out.println(Byte.MIN_VALUE);
		
		sc.close();
	}

}
