package com.nareshitjavaprgs;

public class SumOfNaturalNumber {

	public static void main(String[] args) {
		
		System.out.println("Sum of 100 natural numbers : ");
		int sum =0;

		for(int i = 1; i<=100; i++) {
			
			sum+=i;
		}
		System.out.println(sum);
	}

}
