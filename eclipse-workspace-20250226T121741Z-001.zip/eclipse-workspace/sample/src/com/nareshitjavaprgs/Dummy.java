package com.nareshitjavaprgs;

public class Dummy { public static void main(String[] args) 
{
    
	int c = 0b1010101;
	 System.out.println(c);
}
}
