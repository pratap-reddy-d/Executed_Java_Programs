package com.nareshitjavaprgs;

public class AverageOfThreeNumbersCLA {

	public static void main(String[] args) {
		float number1 = Float.parseFloat(args[0]);
		float number2 = Float.parseFloat(args[1]);
		float number3 = Float.parseFloat(args[2]);
		
		int argumentlen = args.length;
		
		System.out.println("Average of three numbers is: "+((number1+number2+number3)/argumentlen));
		
		
	}
}
