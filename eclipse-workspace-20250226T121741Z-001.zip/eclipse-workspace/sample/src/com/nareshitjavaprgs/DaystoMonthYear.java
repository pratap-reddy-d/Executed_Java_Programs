package com.nareshitjavaprgs;

import java.util.Scanner;
public class DaystoMonthYear {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int days = sc.nextInt();
		
		int years = days/365;
		
		int months = (days%365)/30;
		
		int days1 = ((days%365)%30);
		
		System.out.println("years: "+years);
		System.out.println("Months: "+months);
		System.out.println("Days: "+days1);
		
		sc.close();
	}

}
