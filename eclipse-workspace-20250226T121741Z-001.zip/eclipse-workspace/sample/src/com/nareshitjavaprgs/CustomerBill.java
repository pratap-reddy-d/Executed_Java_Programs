package com.nareshitjavaprgs;

public class CustomerBill {

	public static void main(String[] args) {
		
		int chickenRoll = 60;
		int vegPuffs = 25;
		int discount = 50;
		
		int chickCount = 4;
		int vegCount = 3;
		
		int totalBill = chickenRoll*chickCount + vegPuffs*vegCount - discount;
		
		System.out.println("Bill :"+totalBill);
	}
}
