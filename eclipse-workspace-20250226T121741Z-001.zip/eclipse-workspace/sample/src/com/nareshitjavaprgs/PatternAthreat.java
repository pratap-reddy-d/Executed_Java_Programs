package com.nareshitjavaprgs;

public class PatternAthreat {

	public static void main(String[] args) {
	/*	
		for(int i=0;i<8;i++) {
				System.out.print("@");
		}
		System.out.println();
		
		
		for(int j=0;j<5;j++) {
			for(int i=0;i<8;i++) {
				if(i==0 || i==7) {
				System.out.print("@");
				}
				else
					System.out.print(" ");
			}System.out.println();
		}
				
		for(int i=0;i<8;i++) {
			System.out.print("@");
		}
		*/
		System.out.println("@@@@@@@@");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@@@@@@@@");
	}
}
