package com.nareshitjavaprgs;

public class TvProfitBill {

	public static void main(String[] args) {
	
		int costPrice = 32500;
		
		int sellingProfit = 27;
		float vatPercent = 12.7f;
		float serviceChargePercent = 3.87f;
		
		float profit = (costPrice*sellingProfit)/100;
		
		float sellingPrice = costPrice+profit;
		
				
		float vat = (sellingPrice*vatPercent)/100;
		
		float serviceCharge = (sellingPrice*serviceChargePercent)/100;
		
		
		
		System.out.println("Total Selling Price: "+(serviceCharge+vat+sellingPrice));
		System.out.println("Profit"+profit);
		System.out.println("vat "+vat);
		System.out.println("service charge "+serviceCharge);
		
		System.out.println("Profit along with vat and service charge: "+(vat+serviceCharge+profit));
		
		
		

	}

}
