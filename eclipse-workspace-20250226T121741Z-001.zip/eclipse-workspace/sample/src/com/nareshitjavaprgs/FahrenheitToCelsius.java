package com.nareshitjavaprgs;

import java.util.Scanner;

public class FahrenheitToCelsius {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter fahrenheit :");
		float fahrenheit = sc.nextFloat();
		float celsius ;
		
		
		celsius = (fahrenheit-32)*5/9;
		celsius = Math.round(celsius);
		
		System.out.println("Converterted Temperature is: "+celsius+"celsius");
		
		sc.close();
	}

}
