package com.nareshitjavaprgs;

public class CubeOfNumberCLA {

	public static void main(String[] args) {
		int number = Integer.parseInt(args[0]);
		System.out.println("Cube is: "+(number*number*number)); // ctrl+space
	}
}
