package com.nareshitjavaprgs;

import java.util.Scanner;
public class ProfitAndLoss {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		double profit ;
		double loss ;
		double profitPercentage ;
		double lossPercentage  ;	
		double sellingPrice;
		double costPrice;
		
		System.out.println("Enter Cost Price :");
		costPrice = sc.nextInt();
		
		System.out.println("Enter Selling price: ");
		sellingPrice = sc.nextInt();
		
		if(costPrice<sellingPrice) {
		
			profit = sellingPrice - costPrice;
			profitPercentage = profit/costPrice*100;
			
			System.out.println("Profit is: "+profit);
			System.out.println("Profit Percentage is: "+profitPercentage);
		}
		else {
		
			loss = costPrice - sellingPrice;
			lossPercentage = (loss/costPrice)*100;
			
			System.out.println("Loss is: "+loss);
			System.out.println("Loss Percentage is: "+lossPercentage);	
		}			
		
		sc.close();
	}	
}
