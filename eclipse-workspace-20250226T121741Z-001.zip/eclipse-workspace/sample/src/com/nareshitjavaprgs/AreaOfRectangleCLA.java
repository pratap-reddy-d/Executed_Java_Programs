package com.nareshitjavaprgs;

public class AreaOfRectangleCLA {

	public static void main(String[] args) {
		int length = Integer.parseInt(args[0]);
		int breadth = Integer.parseInt(args[1]);
		
		System.out.println("Area of Rectangle is :"+(length*breadth));
	}

}
