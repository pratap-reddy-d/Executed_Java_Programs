package com.nareshitjavaprgs;

public class RohanCycleBill {

	public static void main(String[] args) {
		
		int originalPrice = 1200;
		int repairs = 250;
		int coloring = 350;
		int newAccessories = 500;
		
		int profit = 1500;
		
		int total = originalPrice+repairs+coloring+newAccessories;
		
		int sellingPrice  = total+profit;
		
				
		System.out.println("Selling Price :"+sellingPrice);

	}

}
