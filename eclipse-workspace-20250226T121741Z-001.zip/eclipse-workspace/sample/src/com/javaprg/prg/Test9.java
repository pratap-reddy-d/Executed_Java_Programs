package com.javaprg.prg;

public class Test9{
	public static void main(String[] args) {
		int x  = 10;
		int y = 12;
		
		sum(x,y);
		
		Test9 n = new Test9();
		
		System.out.println(n);
		
	}
	static void sum(int x, int y) {
		
		System.out.println(x+y);
	}
}