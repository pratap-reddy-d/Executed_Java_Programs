package com.demo2pro;

public class Subtract {

	public static int sub(int a, int b) {
		return a-b;
	}
}
