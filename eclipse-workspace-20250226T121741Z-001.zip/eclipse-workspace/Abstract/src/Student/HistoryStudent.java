package Student;

public class HistoryStudent extends Student {

	private int historyMarks = 45;
	private int civicsMarks = 76;
	
	
	@Override
	public int getPercentage() {
		int per = (historyMarks+civicsMarks)/2;
		return per;
	}

}
