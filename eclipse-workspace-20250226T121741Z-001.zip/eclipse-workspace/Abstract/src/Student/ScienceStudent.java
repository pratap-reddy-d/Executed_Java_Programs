package Student;

public class ScienceStudent extends Student{

	private int physicsMarks = 89;
	private int chemistryMarks = 67;
	private int mathsMarks = 76;
	
	
	
	@Override
	public int getPercentage() {
		int per = (physicsMarks+chemistryMarks+mathsMarks)/3;
		return per;
	}

}
