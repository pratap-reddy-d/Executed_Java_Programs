package Student;

public class StudentTester {

	public static void main(String[] args) {
		
		
		ScienceStudent  ss = new ScienceStudent();
		System.out.println(ss.getPercentage());
		
		HistoryStudent hs = new HistoryStudent();
		System.out.println(hs.getPercentage());
		
		
	}

}
