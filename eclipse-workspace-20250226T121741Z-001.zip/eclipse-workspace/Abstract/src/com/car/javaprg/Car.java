package com.car.javaprg;

abstract class Car {

	 String brand;
	 String model;
	 int mileage;
	 int top_speed;
	 int yearOfManufacturing;
	 
	 public Car() {
		super();
		this.brand = "Fortuner";
		this.model = "Adventure";
		this.mileage = 30;
		this.top_speed = 220;
		this.yearOfManufacturing = 2024;
	}

	String carBrand() {
		 return ""+brand;
	 }
	 
	 String carModel() {
		 return ""+model;
	 }
	 
	 int carMileage() {
		 return mileage;
	 }
	 
	 int carTopSpeed() {
		 return top_speed;
	 }
	 
	 int carYear() {
		 return yearOfManufacturing;
	 }
	 
	abstract void display();	 
	 
}
