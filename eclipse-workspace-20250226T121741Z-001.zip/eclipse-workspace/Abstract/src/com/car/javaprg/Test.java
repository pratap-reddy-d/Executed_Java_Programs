package com.car.javaprg;

public class Test extends Car {

	public static void main(String[] args) {
		Test t = new Test();
		t.display();
	}

	@Override
	void display() {
		
		System.out.println("Car Brand = "+super.brand);
		System.out.println("Car Model = "+super.model);
		System.out.println("Car Mileage = "+super.mileage);
		System.out.println("Car TopSpeed = "+super.top_speed);
		System.out.println("Car Year of Mafacture = "+super.yearOfManufacturing);
		
	}

}
