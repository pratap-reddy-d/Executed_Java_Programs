package com.javaprg.nutrition;

public class Egg extends Food {
	
	String type = "non-vegetarian";

	public Egg(double protiens,double carbs,double fats) {
		this.carbs = carbs;
		this.fats = fats;
		this.proteins = protiens;
		this.tastyScore = 7;
	}
	
	@Override
	void getMacroNutrients() {
	
		System.out.println("An egg has "+ this.proteins +"gms of protein,"+ this.fats +"gms of fats and "+ this.carbs +" gms of carbohydrates.");
	}

}
