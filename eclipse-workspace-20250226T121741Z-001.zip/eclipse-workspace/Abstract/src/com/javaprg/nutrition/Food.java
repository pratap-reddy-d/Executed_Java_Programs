package com.javaprg.nutrition;

abstract class Food {

	double proteins;
	double fats;
	double carbs;
	double tastyScore;
	abstract void getMacroNutrients();
	
}
