package com.javaprg.nutrition;

public class Bread extends Food{

	String type = "vegetarian";
	
	public Bread(double protiens,double carbs,double fats) {
		this.carbs = carbs;
		this.fats = fats;
		this.proteins = protiens;
		this.tastyScore = 8;
	}
	@Override
	void getMacroNutrients() {
		System.out.println("An slice of bread has "+ this.proteins +"gms of protein,"+ this.fats +"gms of fats and "+ this.carbs +" gms of carbohydrates.");
		
	}

	
	
}
