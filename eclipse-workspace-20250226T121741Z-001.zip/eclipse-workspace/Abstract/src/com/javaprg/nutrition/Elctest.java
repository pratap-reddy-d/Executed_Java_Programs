package com.javaprg.nutrition;

import java.util.Scanner;

public class Elctest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n  = sc.nextInt();
		String foodName = sc.next();
		String getType = sc.next();
		String getMacros = sc.next();
		String getTaste = sc.next();
		
		if(n ==  1) {
		Egg e = new Egg(4.0, 1.1, 13.8);
		
		e.getMacroNutrients();}
		
		if(n ==  2) {
		Bread b = new Bread(0, 0, 0);
		
		b.getMacroNutrients();}
		
	}

}
