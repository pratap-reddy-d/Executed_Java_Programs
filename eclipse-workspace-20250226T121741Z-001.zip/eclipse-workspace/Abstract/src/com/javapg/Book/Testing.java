package com.javapg.Book;

import java.util.Scanner;

public class Testing {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter title name");
		String t = sc.nextLine();
		MyBook mb = new MyBook();
		
		mb.setTitle(t);
		System.out.println(mb.getTitle());
	}

}
