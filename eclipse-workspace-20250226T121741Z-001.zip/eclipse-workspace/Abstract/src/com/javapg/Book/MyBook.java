package com.javapg.Book;

public class MyBook extends Book{

	@Override
	void setTitle(String title) {
		super.title = title;
		
	}

	@Override
	String getTitle() {
		return "The title of my book is:"+title;
	}

}
