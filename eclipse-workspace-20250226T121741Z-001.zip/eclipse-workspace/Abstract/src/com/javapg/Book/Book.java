package com.javapg.Book;

abstract public class Book {

	String title;
	abstract void setTitle(String title);
	abstract String getTitle();
}
