package com.javapg.advancearithmetic;

public class FullTimeEmployee implements Employee {

	private int employeeId;
	private String employeeName;
	private double monthlySalary;
	private double benefits;
	
	
	public FullTimeEmployee(int employeeId, String employeeName, double monthlySalary, double benefits) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.monthlySalary = monthlySalary;
		this.benefits = benefits;
	}

	@Override
	public double calculateSalary() {
		double sal=monthlySalary+benefits;
		return sal;
	}

	@Override
	public void generatePayroll() {
		System.out.println("employee id:"+employeeId);
		System.out.println("employee Name:"+employeeName);
		System.out.println("employee monthly salary:"+monthlySalary);
		System.out.println("employee benefits:"+benefits);
		
	}

}
