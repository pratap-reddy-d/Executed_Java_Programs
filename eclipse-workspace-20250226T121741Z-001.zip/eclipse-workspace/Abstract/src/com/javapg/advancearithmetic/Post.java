package com.javapg.advancearithmetic;

public interface Post {
public void publish();
public void like();
}
