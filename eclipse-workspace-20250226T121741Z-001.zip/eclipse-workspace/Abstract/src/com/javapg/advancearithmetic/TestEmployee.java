package com.javapg.advancearithmetic;

public class TestEmployee {

	public static void main(String[] args) {
		
		FullTimeEmployee fte = new FullTimeEmployee(12021, "ashik", 120000, 900);
		fte.generatePayroll();
		System.out.println("total salary: "+fte.calculateSalary());
	}

}
