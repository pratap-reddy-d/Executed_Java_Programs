package com.javapg.advancearithmetic;

public class MyCalculator implements AdvancedArithmetic {

	int n,sum;
	
	public MyCalculator(int n) {
		super();
		if(n>0)
		this.n = n;
		else System.err.println("Input must be a positive integer");
	}

  
	@Override
	public int divisorSum() {
		
			for(int i=1;i<=n;i++){
				if(n%i==0) {
				 sum = sum + i;
				}
			}
		return sum;
				
	}

	
}
