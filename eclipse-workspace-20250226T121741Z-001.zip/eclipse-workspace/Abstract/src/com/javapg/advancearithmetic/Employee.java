package com.javapg.advancearithmetic;

public interface Employee {

	public double calculateSalary();
	
	public void generatePayroll();
	
}
