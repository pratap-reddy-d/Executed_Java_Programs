package com.shape.javaprg;

public class Triangle extends Shape{

	double base;
	double height;
	
	
	public Triangle(double base, double height) {
		super();
		this.base = base;
		this.height = height;
	}

	@Override
	double getArea() {
		double area = 0.5*base*height;
		return area;
	}

	@Override
	void printDetails() {
		System.out.println("Type = Triangle");
		System.out.println("Length = "+ base);
		System.out.println("Breadth = "+height);
		System.out.println("Area = "+getArea());
	}

}
