package com.shape.javaprg;

public class Testing {

	public static void main(String[] args) {
		
		Rectangle re = new Rectangle(30.3,45.4);
		re.printDetails();
		
		Circle c = new Circle(23.2);
		c.printDetails();
		
		Triangle t = new Triangle(146.2,40.0);
		t.printDetails();
		

	}

}
