
@FunctionalInterface
interface A{
	int cube(int b);
}

public class Functioninterface {

	public static void main(String[] args) {
	int a= 21;
	
	A obj = (b) ->  b*b*b;
	    
	/*
		A obj = new A() {
			@Override
			public int cube(int b) {
				return b*b*b;
			}
		};
		System.out.println(obj.cube(a));
		
		*/
	System.out.println(obj.cube(a));
	}
}
