package com.javaprg.StreamMethods;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class EmptyStringFilter {

	public static void main(String[] args) {
	/*	
		String s1 = "Hello";
		String s2 ="";
		String s3 = "world";
		String s4 = " ";
		String s5 = "from";
		String s6 = " ";
		String s7 = "Java";
		String s8 = "!";
		
		Stream<String> val = Stream.of(s1,s2,s3,s4,s5,s6,s7,s8).filter(str ->!str.isEmpty());
		
		val.forEach(System.out::print);
		
		*/
		List<String> names = Arrays.asList("Hello", "", "World", " ", "from", " ", "Java", "!");
		
		names.stream().filter(str->!str.isEmpty()).forEach(System.out::print);
	}
}
