package com.javaprg.StreamMethods;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SteramFilterOf {

	public static void main(String[] args) {
		/*	
		List<Integer> num = new ArrayList<>();
		num.add(1);
		num.add(2);
		num.add(3);
		num.add(4);
		num.add(5);
		num.add(6);
		num.add(7);
		num.add(8);
		num.add(9);
		num.add(10);
		
		for(int i=0;i<10;i++) num.add(i);
		
		num.stream().filter(val-> val%2==0).forEach(System.out::println);
	
		*/
		
		List<Integer> val = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		
		val.stream().filter(num-> num%2==0).forEach(System.out::println);
	}
}
