package com.javaprg.StreamMethodsStudent;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

record Student(String name,String course) {
	
}
public class StudentFilter {

	public static void main(String[] args) {
		
		Student s1 = new Student("Aice","java");
		Student s2 = new Student("Bob", "Python");
		Student s3 = new Student("Charlie","Python");
		Student s4 = new Student("David", "java");
		Student s5 = new Student("Eve", "java");
		
		Stream<Student> stre =  Stream.of(s1,s2,s3,s4,s5).filter(str -> str.course() == "java");
			
		List<Student> stud = stre.toList();
		
	 for(Student so : stud) {
		 System.out.println(so.name());
	 }
	}
}
