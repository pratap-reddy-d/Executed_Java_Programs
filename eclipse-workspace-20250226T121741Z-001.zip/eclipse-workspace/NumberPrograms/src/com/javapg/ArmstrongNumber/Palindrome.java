package com.javapg.ArmstrongNumber;


class Solution {
    public boolean isPalindrome(int x) {
        int temp = x;
        int sum =0;
        if(x>0){
             while(x!=0){
            int y = x%10; sum = sum*10;
            sum = sum+y;
            x=x/10;
        }
        }
       
        if(temp == sum)
        return true;
        else return false;
    }
}
public class Palindrome {

	public static void main(String[] args) {
		
		int number = 121;
		int sum =0;
		int temp = number;
		
		while(number!=0) {
			
			int y = number%10;
			sum=sum*10;
			sum = sum+y;
		
			number/=10;
		}
		
		System.out.println(sum);
		System.out.println(temp==sum?true:false);
	}
}
