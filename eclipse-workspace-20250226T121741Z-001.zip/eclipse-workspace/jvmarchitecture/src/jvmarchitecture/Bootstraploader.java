package jvmarchitecture;

class Inerty{
	
}

public class Bootstraploader {

	public static void main(String[] args) {
		
		Class cls = Inerty.class;
		
		System.out.println(cls.getClassLoader());
		System.out.println(cls.getClassLoader().getParent());
		System.out.println(cls.getClassLoader().getParent().getParent());
	// application loader / 
		// platform class loader / extension
		//bootstrap loader = null / primodial 
	}
}
