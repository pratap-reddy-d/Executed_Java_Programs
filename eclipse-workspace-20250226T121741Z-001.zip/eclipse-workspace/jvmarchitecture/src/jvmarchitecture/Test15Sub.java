package jvmarchitecture;

	public class Test15Sub {
			public static void main(String[] args) {
				System.out.println(Test15Sub.class.getClassLoader());
				System.out.println(Test15Sub.class.getClassLoader().getParent());
				System.out.println(Test15Sub.class.getClassLoader().getParent().getParent());
			}
		}