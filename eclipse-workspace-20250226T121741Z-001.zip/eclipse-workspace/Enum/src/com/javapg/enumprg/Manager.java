package com.javapg.enumprg;

public class Manager extends Employee{

	private ManagerType type;
	
	public Manager() {
		super();
		this.type = ManagerType.HR;
	}

	
	public Manager( String name,int employeeId,double salary,ManagerType type) {
		super(name,employeeId,salary);
		this.type = type;
	}


	public ManagerType getType() {
		return type;
	}

	public void setType(ManagerType type) {
		this.type = type;
	}

	
	@Override
	public void setSalary(double salary){
	//	System.out.println(super.salary);
		if(getType() == ManagerType.HR) {
			
		super.setSalary(salary + 10000);
		}
		else if(type == ManagerType.SALES) super.setSalary(salary+5000);
		
	}

	
	
	
}
