package examtoday.com;

public class CarRental {

	public static void main(String[] args) {
	
		RenterBlc re = new RenterBlc(1,"pratap","hyd",null);
		
		System.out.println(re);

	}
}
