package examtoday.com;

public class MainElc {

	public static void main(String[] args) {
		
		for(int i=0;i<5;i++) {
			System.out.println(EmployeeBlc.getEmployeeObject());
			
		}
		
		
		
	}

}
