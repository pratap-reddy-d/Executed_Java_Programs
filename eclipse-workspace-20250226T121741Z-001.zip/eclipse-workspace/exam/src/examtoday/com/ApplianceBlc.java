package examtoday.com;

public class ApplianceBlc {

	private String applianceName;
	private int powerRating;
	private String applianceType;
	
	public ApplianceBlc() {
		this.applianceName = "Laptop";
		this.applianceType = "Electronic";
		this.powerRating = 50;
	}

	public ApplianceBlc(String applianceName, int powerRating) {
		super();
		if(applianceName != null)
		this.applianceName = applianceName;
		else System.err.println("Invalid input");
		
		if(powerRating > 0)
		this.powerRating = powerRating;
		else System.err.println("Error: Power rating must be positive");
	}

	public ApplianceBlc(String applianceName, int powerRating, String applianceType) {
		super();
		if(applianceName != null)
		this.applianceName = applianceName;
		else System.err.println("Invalid input");
		
		if(powerRating > 0)
		this.powerRating = powerRating;
		else System.err.println("Error: Power rating must be positive");
		
		if(applianceName != null)
		this.applianceType = applianceType;
		else System.err.println("Invalid input");
	}
	
	public void displayInfo() {
		System.out.println("Appliance Name = " + applianceName );
		System.out.println("Power Rating = " + powerRating);
		System.out.println("Appliance Type = "+applianceType);
	}

	@Override
	public String toString() {
		
		return "ApplianceBlc [applianceName=" + applianceName + ", powerRating=" + powerRating + ", applianceType="
				+ applianceType + "]";
	}



	
}
