package examtoday.com;

import java.util.Scanner;

public class EmployeeBlc {

	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	
	public EmployeeBlc(int employeeId, String employeeName, double employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}
	
	static Scanner sc = new Scanner(System.in);
	
	public static EmployeeBlc getEmployeeObject() {
		System.out.println("Enter the values:");
		System.out.println("Enter Employee Id: ");
		int employeeId = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Employee Name: ");
		String employeeName = sc.nextLine();
		System.out.println("Enter Employee Salary: ");
		double employeeSalary = sc.nextDouble();
		
		EmployeeBlc emp = new EmployeeBlc(employeeId, employeeName, employeeSalary);
		
		return emp ;
	}


	@Override
	public String toString() {
		return "EmployeeBlc [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + "]";
	}
	
}
