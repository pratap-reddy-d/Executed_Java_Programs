package examtoday.com;

public class CarBlc {

	private int carId;
	private String model;
	private double dailyRate;
	public CarBlc(int carId, String model, double dailyRate) {
		super();
		this.carId = carId;
		this.model = model;
		this.dailyRate = dailyRate;
	}
	@Override
	public String toString() {
		return "CarBlc [carId=" + carId + ", model=" + model + ", dailyRate=" + dailyRate + "]";
	}
	
	
	
}
