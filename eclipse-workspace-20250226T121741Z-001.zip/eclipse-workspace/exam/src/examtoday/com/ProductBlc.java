package examtoday.com;

import java.util.Scanner;

public class ProductBlc {

	private int productId;
	private  String productName;
	private double productPrice;
	
	
	
	public ProductBlc(int productId, String productName, double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}

	static Scanner sc = new Scanner(System.in);
	
	public static ProductBlc getProductObject() {
		System.out.println("Enter product Id: ");
		int productId = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter product Name: ");
		String productName = sc.nextLine();
		
		System.out.println("Enter product Price: ");
		double productPrice = sc.nextDouble() ;
		
		ProductBlc pro = new ProductBlc(productId,productName,productPrice); 
		return pro;
	}

	@Override
	public String toString() {
		return "ProductBlc [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", sc=" + sc + "]";
	}
	
	
}
