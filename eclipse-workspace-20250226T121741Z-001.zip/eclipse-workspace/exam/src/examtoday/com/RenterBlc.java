package examtoday.com;

public class RenterBlc{

	private int renterId;
	private String renterName;
	private String renterAddress;
	private CarBlc Car;
	
	public RenterBlc(int renterId, String renterName, String renterAddress, CarBlc car) {
		super();
		this.renterId = renterId;
		this.renterName = renterName;
		this.renterAddress = renterAddress;
		 Car = new CarBlc(120, "HYd", 123);
	}

	@Override
	public String toString() {
		return "RenterBlc [renterId=" + renterId + ", renterName=" + renterName + ", renterAddress=" + renterAddress
				+ ", Car=" +Car+ "]";
	}

	
	
	
}
