package com.javapg.mulithreadingsetA;

 abstract public class Student extends Thread {

	 protected String studentName;
	 protected String studentClass;
	 protected String totalNoOfStudents;
	 
	 synchronized static void incrementTotalNoOfStudents() {
		 
	 }
	 abstract  int getPercentage() ;
	 abstract boolean getTotalNoOfStudents();
	 
	 public Student() {
		 super();
	 }
	public Student(String studentName, String studentClass, String totalNoOfStudents) {
		super();
		this.studentName = studentName;
		this.studentClass = studentClass;
		this.totalNoOfStudents = totalNoOfStudents;
	}
	 
	 
	 
}
