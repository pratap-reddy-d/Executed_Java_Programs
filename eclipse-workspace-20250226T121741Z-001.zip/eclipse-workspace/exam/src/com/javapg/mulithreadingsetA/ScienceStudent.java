package com.javapg.mulithreadingsetA;

public class ScienceStudent extends Student {

	private int physicsMarks;
	private int chemistryMarks;
	private int mathsMarks;
	
	private int percentage;
	private boolean percentageCalculated = false;
	
	
	
	public ScienceStudent(String studentName, String studentClass, String totalNoOfStudents,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super(studentName,studentClass, totalNoOfStudents);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}

	@Override
	int getPercentage() {
		percentage = (physicsMarks+chemistryMarks+mathsMarks/300)*100;
		
		return percentage;	
	//	Thread.notify();
	}

	@Override
	boolean getTotalNoOfStudents() {
		// TODO Auto-generated method stub
		return false;
	}

}
