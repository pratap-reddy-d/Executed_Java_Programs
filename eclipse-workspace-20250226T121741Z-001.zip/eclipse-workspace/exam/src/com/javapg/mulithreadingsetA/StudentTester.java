package com.javapg.mulithreadingsetA;

public class StudentTester {
	public static void main(String[] args) {
	
		ScienceStudent ss = new ScienceStudent("Virat","12th","4",85,40,35);
		
		HistoryStudent hs = new HistoryStudent();
		
		Thread percentage = new Thread();
		
		Thread promotion = new Thread();
		
		percentage.start();
		promotion.start();
		
		System.out.println(ss);
	}	
}
