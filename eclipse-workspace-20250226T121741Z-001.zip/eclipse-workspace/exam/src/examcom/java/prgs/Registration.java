package examcom.java.prgs;

public class Registration {

	String registrationDate;
	String owner;
	String vehicle;
	
	void setRegistrationDetails(String registrationDate, String owner, String vehicle) {
		
		this.registrationDate = registrationDate;
		this.owner = owner;
		this.vehicle = vehicle;
	}
	String getRegistrationDetails() {
		
		return "\n"+registrationDate+"\n"+owner+"\n"+vehicle;
	}
}
