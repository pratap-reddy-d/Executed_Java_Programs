package examcom.java.prgs;

import java.util.Scanner;

public class RegistationElc {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String registrationDate;
		String owner;
		String vehicle;
		
		System.out.println("Enter the Registration Date: ");
		registrationDate = sc.nextLine();
		
		System.out.println("Enter the Owner Name: ");
		owner = sc.nextLine();
		
		System.out.println("Enter the Vehicle Name: ");
		vehicle = sc.nextLine();
		
		
		Registration re = new Registration();
		
		 re.setRegistrationDetails(registrationDate, owner, vehicle);
		System.out.println(re.getRegistrationDetails());
		 
		 
		sc.close();
	}
}
