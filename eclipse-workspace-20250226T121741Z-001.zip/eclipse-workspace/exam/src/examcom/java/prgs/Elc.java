package examcom.java.prgs;

import java.util.Scanner;

public class Elc {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String planetName;
		double mass;
		double radius;
		
		System.out.println("Enter the planet name: ");
		planetName = sc.nextLine();
		
		System.out.println("Enter the planet mass in kilograms: ");
		mass = sc.nextInt();
		
		System.out.println("Enter the planet radius in kilometers: ");
		radius = sc.nextInt();
		
		Planet p = new Planet();
		
		p.setPlanetDetails(planetName, mass, radius);
		
		String d = p.getPlanetDetails();
		
	System.out.println(d);

		
		sc.close();
		
	}
}
