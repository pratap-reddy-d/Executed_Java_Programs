package com.javapg.task2;

public class NewPlatForm4 {
public static void main(String[] args) {
	
	{
		new Thread() {
			public void run() {
				for(int i=0;i<=(3^5);i++) {
					System.out.println("Enjoy your newplatform.."+i);
				}
			}
		}.start();
		
		new Thread() {
			public void run() {
				for(int i=0;i<=(3^5);i++) {
					int n=10;
					if(i==(n/=n/=2))
					System.out.println("Experience your newplatform.."+i);
				}
			}
		}.start();
	}
}
}
