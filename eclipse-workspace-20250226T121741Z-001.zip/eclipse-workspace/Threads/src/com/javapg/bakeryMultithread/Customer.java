package com.javapg.bakeryMultithread;

public class Customer implements Runnable {

	private final Bakery bakery;
	
	private final String customerName;
	
	public Customer(Bakery bakery, String customerName) {
		super();
		this.bakery = bakery;
		this.customerName = customerName;
	}

	@Override
	public void run() {
		
		try {
			while(!bakery.isProductionFinished()) {
				bakery.buyGoods(customerName);
				Thread.sleep(500);
			}
		}
		catch(InterruptedException e) {
			
		}
		System.out.println(customerName + " is done shopping for the day.");
	}	
}
