package com.javapg.threadtask;

class NIT17 extends Thread
{
	@Override
	public void run() {
		System.out.println(currentThread().getName());
		System.out.println(currentThread().getPriority());
	}
}

public class Without_start {
	public static void main(String[] args) throws InterruptedException {
		NIT17 nit = new NIT17();
		nit.run();
}}
