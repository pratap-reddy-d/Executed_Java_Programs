package com.javapg.threadtask;

public class Anonymous_Thread {

	public static void main(String[] args) {
	
		//anonymous Thread
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("nit");
			}
		}).start();
 System.out.println(new Thread().isAlive());
 
 //thread
 	 		
 		Runnable r = new Runnable() {
 			@Override
 			public void run() {
 				System.out.println("nit1");
 			}
 		};
 		Thread t1 = new Thread(r);
 		t1.start();
 		
 		System.out.println(t1.isAlive());
 
	}

}
