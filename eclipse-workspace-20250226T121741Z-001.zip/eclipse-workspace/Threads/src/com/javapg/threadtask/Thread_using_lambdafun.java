package com.javapg.threadtask;

public class Thread_using_lambdafun {

	public static void main(String[] args) {
		
		new Thread( ()-> System.out.println("NIT")
				).start();
	}
}
