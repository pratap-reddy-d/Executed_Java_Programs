package com.javapg.threadtask;

class NIT11 extends Thread
{
	@Override
	public void run() {
	//	System.out.println(currentThread().getId());
		System.out.println(currentThread().getName());
		System.out.println(currentThread().getPriority());
	}
}

public class SingleClass_multiref {
	public static void main(String[] args) throws InterruptedException {
		NIT11 nit = new NIT11();
		NIT11 nit1 = new NIT11();
		NIT11 nit2 = new NIT11();
		nit.start();
		nit.setName("first");
	//	nit.setPriority(Thread.NORM_PRIORITY);
	//	nit.setPriority(Thread.MIN_PRIORITY);
		nit.setPriority(Thread.NORM_PRIORITY);
		nit1.start();
		nit1.setName("second");
		nit1.setPriority(Thread.MIN_PRIORITY);
		nit2.start();
		nit2.setName("third");
		nit2.setPriority(Thread.MAX_PRIORITY);
    }
}
