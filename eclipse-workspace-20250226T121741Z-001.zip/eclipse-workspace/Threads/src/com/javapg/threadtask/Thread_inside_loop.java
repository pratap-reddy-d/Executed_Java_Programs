package com.javapg.threadtask;

class NIT18 extends Thread
{
	@Override
	public void run() {
		System.out.println(currentThread().getId());
	}
}
public class Thread_inside_loop {
	public static void main(String[] args) throws InterruptedException {
		for(int a = 0; a<10;a++) 
		{
		  Thread newThread = new Thread(new NIT18());
		  newThread.start();
		}
    }
}
