package com.javapg.threadtask;

public class Exe extends Thread{

	public void display() {
		for(int a=0;a<5;a++) 
		{
			System.out.println("display");
		}
	}
	public void display1() {
		for(int a=0;a<5;a++) 
		{
			System.out.println("display-1");
		}
	}
	public static void main(String[] args) throws InterruptedException {
		Exe j = new Exe();
		
		j.start();
		j.display();
		j.wait(); // error -> not a owner
		j.sleep(1000); // no error
		j.display1();
	}
	
}
