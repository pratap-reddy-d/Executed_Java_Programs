package com.javapg.threadtask;

class T1 extends Thread{
	@Override
	public void run(){
		for(int a=0;a<5;a++) {
			System.out.println("T1 display");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class T2 extends Thread{
	public void run() {
		for(int a=0;a<5;a++) {
			System.out.println("T2 display");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

public class Thread_serialexe {

	public static void main(String[] args) throws InterruptedException {
		
		T1 t1 = new T1();
		
		T2 t2 = new T2();
		
		t1.start();
		t2.start();
		
		
	}
}
