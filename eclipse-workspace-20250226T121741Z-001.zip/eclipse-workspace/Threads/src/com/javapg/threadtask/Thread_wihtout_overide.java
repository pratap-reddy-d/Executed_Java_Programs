package com.javapg.threadtask;

public class Thread_wihtout_overide extends Thread{

	@Override
	public void run() {
		if(Thread.currentThread().isDaemon()) {
			System.out.println("Deamon thread running. ");
		}
		else System.out.println("normal thread running");
	}
	
	public static void main(String[] args) {
	//	System.out.println(Thread.currentThread().isDaemon());
	/*	
		if(Thread.currentThread().isDaemon()) {
			System.out.println("Deamon thread running. ");
		}
		else System.out.println("normal thread running");
		
		Thread_wihtout_overide n = new Thread_wihtout_overide();
		Thread_wihtout_overide n1 = new Thread_wihtout_overide();
		Thread_wihtout_overide n2 = new Thread_wihtout_overide();
		Thread_wihtout_overide n3 = new Thread_wihtout_overide();
		
		n2.setDaemon(true);
		
		n.start();
		n1.start();
		n2.start();
		n3.start();
		
		*/
		
		Thread_wihtout_overide n = new Thread_wihtout_overide();
		Thread_wihtout_overide n1 = new Thread_wihtout_overide();
		Thread_wihtout_overide n2 = new Thread_wihtout_overide();
		Thread_wihtout_overide n3 = new Thread_wihtout_overide();
		
		n2.setDaemon(true);
		
		n.start();
		n1.start();
		n2.start();
		n3.start();
	}
}
