package com.javapg.multithreadingPetrolFiling;

public class PetrolPumpSimulation{

	public static void main(String[] args) {
		
		PetrolPump p = new PetrolPump();
		
		Car c[] = {
				new Car("frotuner", p),
				new Car("thar",p),
				new Car("inoova",p)
		};
	
		
		Thread t[] = {
				new Thread(c[0],"innova"),
				new Thread(c[1],"crysta"),
				new Thread(c[2],"maze")
		
		};
		
		
			t[0].start();t[1].start();t[2].start();
		
		
		
	//	System.out.println(Thread.activeCount());
	}

}
