package com.javapg.collections_vector;

import java.util.*;
public class VectorDemo1 {
public static void main(String[] args) {
	
	//Array
	int[] array = new int[5];
	
	for(int i=5;i>0;i--) 
		array[5-i] = i;
	
	System.out.println(Arrays.toString(array));
	Arrays.fill(array,1,4,8); // fill 8 with 1 to 3 index
	
	for(int i=0;i<5;i++)
		System.out.println(array[i]);
	
	
}
}
