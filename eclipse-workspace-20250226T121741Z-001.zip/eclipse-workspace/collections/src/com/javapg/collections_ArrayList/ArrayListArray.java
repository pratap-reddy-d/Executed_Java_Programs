
package com.javapg.collections_ArrayList;

import java.util.*;

public class ArrayListArray {

	public static void main(String[] args) {
		
		ArrayList<Integer> ar1 = new ArrayList<Integer>();
		
		for(int i=0;i<6;i++) {
			ar1.add(i+1);
		}
		
		System.out.println(ar1);
		
		Object[] ob1 = ar1.toArray();
		
		System.out.println(Arrays.toString(ob1));
 	}
}
