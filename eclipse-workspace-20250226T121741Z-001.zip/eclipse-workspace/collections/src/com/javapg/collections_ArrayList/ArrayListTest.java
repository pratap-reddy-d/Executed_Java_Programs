package com.javapg.collections_ArrayList;

import java.util.*;
public class ArrayListTest {

	public static void main(String[] args) {
		
	//list is a 		
		List<String> list  = new ArrayList<String>();
		
		list.add("patna");
		list.add(0,"New York");
		list.add("Mumbai");
		list.add(2,"sydeny");
		
	//	System.out.println(list);
		
		List<String> list1 = new ArrayList<String>();
		list1.add("Orange");
		list1.add(0,"Banana");
		
		ArrayList<String> ar1 = new ArrayList<>();
		ar1.add("Apple");
		list1.add("Grapes");
		list1.addAll(3, ar1); //from index add next list
		
		System.out.println(list1);
		
		
	}
}
