package com.javapg.Stringtask;

/*
 * package com.nit.stringtask;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map.Entry;

public class Program01 {
   public static void main(String[] args) {
       /*Q- 4
       
       String s = "Umbrella";
       char ch = 'e';
       if(s.contains(ch+"")) {
        System.out.println("Present");
       }else
       System.out.println("Not present");
       */
       /*
        * Q - 5
       String s = "This is orange juice";
       String word = "orange";
       System.out.println("Is present ? : "+s.contains(word));
       */

       /*
       String s = "Hello world";
       char ch = 'o';
       System.out.println("First : "+s.indexOf(ch));
       System.out.println("Last : "+s.lastIndexOf(ch));
       */
       /*
        * Q - 7
       String s = "Robert Brett Roser";
       String[] arr = s.split(" ");
       System.out.println(Arrays.toString(arr));
       String res = "";
       for(int i = 0;i<arr.length-1;i++) {
           res+=arr[i].charAt(0)+".";
       }
       res+=arr[arr.length-1];
       System.out.println(res);
       */

       /*
        * Q - 9
       
       String s = "Hello, have a good day";
       String res = "";
       for(int i = 0;i<s.length();i++) {
           char ch = s.charAt(i);
           if((ch=='a' || ch=='e' || ch=='i' || ch=='o'||ch=='u')) {
               res+=ch;
           }
       }
       System.out.println(res);
       
       String s = "Hello, have a good day";
       
       for(int i = 0;i<s.length();i++) {
           char ch = s.charAt(i);
           if(!(ch=='a' || ch=='e' || ch=='i' || ch=='o'||ch=='u')) {
               s = s.replace(ch+"","");
               i--;
           }
       }
       System.out.println(s);
        */
       
       
       /*
       Write a Java program to reverse a string using the
       StringBuilder class or by implementing your own logic.
       #1
       String s = "Amarjeet";
       for(int i = s.length()-1;i>=0;i--) {
           System.out.print(s.charAt(i));
       }
       
       #2
       String s = "Amarjeet";
       String rev = "";
       for(int i = s.length()-1;i>=0;i--) {
           rev+=s.charAt(i);
       }
       System.out.println(rev);
       
       #3
       String s = "Amarjeet";
       char[] arr = s.toCharArray();
       
       
       for(int i = 0;i<arr.length/2;i++) {
           char temp = arr[i];
           arr[i] = arr[arr.length-i-1];
           arr[arr.length-i-1] = temp;
       }
       String res = new String(arr);
       String rev = String.valueOf(arr);
       System.out.println(res);
       System.out.println(rev);
       
       #4
       String s = "Amarjeet";
       StringBuilder sb = new StringBuilder(s);
       sb.reverse();
       
       s = sb.toString();
       s = String.valueOf(sb);
       s = new String(sb);
       
       System.out.println(sb);
       */
       /*
       Write a Java program to check if a string contains
       only numeric characters using the matches() method with a regular expression.
       
       String s = "837377336747634";
       System.out.println(s.matches("\\d"));
        */
       /*
        * Write a Java program to find the longest word in a
       given string using the split() method and iteration
       
       String s = "Thread starvation is like always being at the back of the line";
       String[] arr = s.split(" ");
       System.out.println(Arrays.toString(arr));
       int maxLength = 0;
       int index = -1;
       for(int i = 0;i<arr.length;i++) {
           if(arr[i].length()>maxLength) {
               maxLength = arr[i].length();
               index = i;
           }
       }
       if(index!=-1) {
           System.out.println("Longest word is : "+arr[index]);
       }else {
           System.out.println("No longest word found");
       }
       */

       /*
       Write a Java program to check if a string is a
       palindrome (reads the same backward as forward) using string manipulation
       methods.
       
       String s = "madam";
       StringBuilder sb = new StringBuilder(s);
       sb.reverse();//malayalam
       if(s.contentEquals(sb)) {
           System.out.println("Palindrome");
       }else {
           System.out.println("Not palindrome");
       }
       
       if(s.equals(sb.toString())) {
           System.out.println("Palindrome");
       }else {
           System.out.println("Not palindrome");
       }
        */
       /*
       Write a Java program to capitalize the first letter of
       each word in a sentence using the split() method and string manipulation.
       
       String s = "India is a great country";
       
       String[] arr = s.split("\\s");
       String res = "";//India Is A
        // 0 1 2 3 4
       //india is a great country
       for (int i = 0; i < arr.length; i++) {
           char ch = arr[i].charAt(0);//a
           if (Character.isLowerCase(ch)) {
               ch -= 32;
           }
           res += ch+arr[i].substring(1)+" ";
       }
       System.out.println(res);
        */
       /*
       Write a Java program to remove duplicate characters
       from a string using the HashSet or an array.
       
        String s = "bookstore";
           char[] arr = s.toCharArray();
           LinkedHashSet<Character> hs = new LinkedHashSet<Character>();
            for(char ch : arr) {
                hs.add(ch);
            }
            System.out.println(hs);
       */
       /*
       Write a Java program to reverse the order of words in
       a sentence using the split() method and iteration
       

       String s = "India is a great country";
       // aidnI si a taerg yrtnuoc
       String[] arr = s.split("\\s");
       String res = "";//aidnI si a
       for (int i = 0; i < arr.length; i++) {
           StringBuilder sb = new StringBuilder(arr[i]);
           sb.reverse();
           res += sb +" ";
       }
       System.out.println(res);
        */
   /*
    *
    * Find the Occurence of String
   
       //Logic : #1 [by using toCharArray() and replacing duplicate char with special character
       String s = "Hello world";
       char[] arr = s.toCharArray();
       
       for(int i = 0;i<arr.length;i++) {
           int count = 1;
           for(int j = i+1;j<arr.length;j++) {
               if(arr[i]==arr[j] && arr[i]!='*') {
                   count++;
                   arr[j] = '*';
               }
           }
           if(arr[i]!='*') {
               System.out.println(arr[i] +" : "+count);
           }
       }
       
       //Logic #2[using toCharArray() and without replacing , creating ine boolean array
       String s = "Hello world";
       char[] arr = s.toCharArray();
       boolean[] res = new boolean[arr.length];
       
       for(int i = 0;i<arr.length;i++) {
           int count = 1;
           for(int j = i+1;j<arr.length;j++) {
               if(arr[i]==arr[j] && res[i]==false) {
                   count++;
                   res[j] = true;
               }
           }
           if(res[i]==false) {
               System.out.println(arr[i] +" : "+count);
           }
       }
       
       //Logic: #3[using toCharArray() without replacing without new array
       String s = "Hello world";
       char[] arr = s.toCharArray();
       
       for(int i = 0;i<arr.length;i++) {
           int c = 1,v = 0;
           for(int j = 0;j<arr.length;j++) {
               if(arr[i]==arr[j] && i<j) c++;
               if(arr[i]==arr[j] && i>j) v++;
           }
           if(v==0) {
               System.out.println(arr[i] +" : "+c);
           }
       }
       
       //Logic #4:[by using ascii values]
       
       String s = "Hello world";
       
       for(int i = 32;i<=122;i++) {
           int count = 0;
           for(int j = 0;j<s.length();j++) {
               if(s.charAt(j)==i) {
                   count++;
               }
           }
           if(count>0) {
               System.out.println((char)i +" : "+count);
           }
       }
       
       //Logic #5 [By using map]
       
       String s = "Hello world";
       LinkedHashMap<Character, Integer> lhm = new LinkedHashMap<Character, Integer>();
       //H : 1 e : 1 l : 2
       for(char ch : s.toCharArray()) {
           if(lhm.containsKey(ch)) {
               lhm.put(ch, lhm.get(ch)+1);
           }else {
               lhm.put(ch, 1);
           }
       }
       
       for(Entry<Character, Integer> e : lhm.entrySet()) {
           System.out.println(e.getKey() +" : "+e.getValue());
       }
       
   }
}
 */
public class StringNotes {

}
