package com.javapg.Stringtask;

/*
Write a Java program to count the occurrences of a
specific substring in a string using the indexOf() method
in a loop.

String s = "java is PI, java is OOPL, java is MT";
String word = "java";
int count = 0; // 3
for(int i = 0;i<s.length();i++) {//1
    int index = s.indexOf(word);//
    System.out.println(index);
    if(index>=0) {
        count++;
        i = index;
        s = s.substring(index+1);//ava is MT
    }else {
        break;
    }
}
System.out.println(count);
*/

public class SubstringOccurenceCount {

	public static void main(String[] args) {
		
		String s = "java is PI, java is OOPL, java is MT";
		
		String word = "java";
		
	System.out.println(s.indexOf(word));
	}
}
