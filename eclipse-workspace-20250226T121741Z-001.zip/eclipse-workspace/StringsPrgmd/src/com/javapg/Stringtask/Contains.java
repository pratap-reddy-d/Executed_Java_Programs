package com.javapg.Stringtask;

public class Contains {
	/*
	public static void main(String[] args) {
		
		String s = "Umbrella";
		
		String c = "e";
		
		if(s.contains(c)) {
			System.out.println("Present");
		}
		else System.out.println("Not Present");
	}
}

class Indexof{
*/
	
	public static void main(String[] args) {
		
		 String s = "Hello worlod";
	       char ch = 'o';
	       System.out.println("First : "+s.indexOf(ch));
	       System.out.println("Last : "+s.lastIndexOf(ch));
	}
}
