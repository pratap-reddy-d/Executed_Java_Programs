package com.javapg.Basicday1;

import java.util.Scanner;


/*
 * Day 1(Basic 10 questions):


1.Write a program to print a string entered by user.


2.Write a program to input and display the sentence I
love candies.


3.Write a program to find the length of the string
"refrigerator".


4.Write a program to check if the letter 'e' is present
in the word 'Umbrella'.


5.Write a program to check if the word 'orange' is
present in the "This is orange juice".


6.Write a program to find the first and the last
occurence of the letter 'o' and character ',' in "Hello, World".


7.Write a program that takes your full name as input and
displays the abbreviations of the first and middle names except the last name
which is displayed as it is. For example, if your name is Robert Brett Roser,
then the output should be R.B.Roser.


8.Write a program to find the number of vowels,
consonents, digits and white space characters in a string.


9.Write a program to delete all consonents from the
string "Hello, have a good day".


10.Input a string of alphabets. Find out the number of
occurrence of all alphabets in that string. Find out the alphabet with maximum
occurrence.
 */
public class Prgs {
	
	 static Scanner sc = new Scanner(System.in);
	public static void PrintingOfString(String s){
		
		System.out.println("The String entered by user is: "+s);
	}

	public static void StringLength(String s){
		
		System.out.println("The length of String is: "+s.length());
		
	}
	
   public static void WordPresent(String s){
		
	   char word = 'e';
		System.out.println(s.contains(word+"")?"present":"Not present");
		
	}
   
   public static void StringPresent(){
		
	  String str = "This is orange juice";
	 
	  String word1 = "orange";
	  
	  System.out.println(str.contains(word1)?"present":"Not present");
	}
   
   
   public static void FirstLastOcuurence() {
	   
	   String s = "Hello, World";
	   char word = 'o';
	   char sym = ',';
	   
	   System.out.println(s.indexOf(word));
	   System.out.println(s.lastIndexOf(word));
	   
	   System.out.println(s.indexOf(sym));
	   System.out.println(s.lastIndexOf(sym));
   }
   
   public static void NameFormat() {
	   
	   String s = sc.nextLine();
	   
	   System.out.println("Enterd name: "+ s);
	   
   }
  
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//String s = sc.nextLine();
		
	//	PrintingOfString(s);
		
	//	StringLength(s);
	//	WordPresent(s);
	//	StringPresent();
		
	//	FirstLastOcuurence();
		
		NameFormat();
		
	}
}
