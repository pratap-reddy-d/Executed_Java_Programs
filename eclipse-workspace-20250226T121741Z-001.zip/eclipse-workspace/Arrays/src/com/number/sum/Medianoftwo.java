package com.number.sum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class Medianoftwo {

	public static void main(String[] args) {
		
		 int[] nums1 = {2,2,4,4};
		 int[] nums2 = {2,2,4,4};	 
		
		Medianoftwo mf = new Medianoftwo();
		
	System.out.println(mf.findMedianSortedArrays(nums1,nums2));
		
	}
	
   public double findMedianSortedArrays(int[] nums1, int[] nums2) {
	   
	  
       int[] res = new int[nums1.length+nums2.length];
       int r1 = res.length;
       
       for(int i=0;i<nums1.length;i++) {
    	   res[i] = nums1[i];
       }
       
       for(int i=0;i<nums2.length;i++) {
    	   res[nums1.length+i] = nums2[i];
       }
	   
       
       for(int j=0;j<r1-1;j++) {
    	   for(int i=0;i<r1-1;i++) {
        	   if(res[i]>res[i+1]) {
        		   int temp = res[i];
            	   res[i] = res[i+1];
            	   res[i+1] = temp;
        	   }    	   
           }
       }
       
       double median = 0;
       
    	   if(r1%2==0) {
    		   median = (res[r1/2] + res[((r1/2)-1)]);
    		   median = median/2;
    	   }
    	   else
    		   median = res[r1/2];
       
	return median;
        
    }

}
