package com.number.sum;

import java.util.Scanner;

public class Palindrome_number {

	public static void main(String[] args) {
		
		Palindrome_number pn = new Palindrome_number();
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println(pn.isPalindrome(n));
		
	}
public boolean isPalindrome(int x) {
	
	int x1 = x;
	int rev = 0;
	
	while(x1!=0 && x1>0) {
		int temp = x1%10;
		rev = rev*10 + temp;
		x1 = x1/10;
	}
	
	if(x==rev)
		return true;
	else
	return false;
        
    }
	
}
