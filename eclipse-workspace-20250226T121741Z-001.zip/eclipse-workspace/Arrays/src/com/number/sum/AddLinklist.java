package com.number.sum;

import java.lang.classfile.components.ClassPrinter.ListNode;
import java.util.Arrays;

public class AddLinklist {
public static void main(String[] args) {
	

	int[] l1 = {9,9,9,9,9,9,9,9};
	int[] l2 = {9,9,9,9};
		
	
	AddLinklist al = new AddLinklist();
	System.out.println(	Arrays.toString(al.addTwoNumbers(rev(l1), rev(l2))));
	
}

public int[] addTwoNumbers(int[] l1, int[] l2) {
	
	
	int[] res = new int[l1.length+1];
	int result =0;
	int result1 =0;
	
	System.out.println(Arrays.toString(l1)+"l1");
	System.out.println(Arrays.toString(l2)+"l2");
	
	for(int i=0;i<l1.length;i++) {
		result = result+l1[i];
		result = result*10;
	}
	
	result = result/10;
	for(int i=0;i<l2.length;i++) {
		result1 = result1+l2[i];
		result1 = result1*10;
	}
	
	result1 = result1/10;
	
	int add = result+result1;
	

	for(int i=add,j=0;i!=0;i=i/10,j++) {
		result = i%10;
		System.out.println(result+"result");
		res[j] = result;
	}
	
	return res;
    
}

public static int[] rev(int[] r) {
	
	int arr1[] = new int[r.length];
	
	for(int j=0,i=r.length-1;i>=0;i--,j++) {
		arr1[j] = r[i];
	}
	
	return arr1;
	
}
}
