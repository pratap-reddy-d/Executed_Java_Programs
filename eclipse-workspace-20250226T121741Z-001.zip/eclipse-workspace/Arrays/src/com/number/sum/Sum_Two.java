package com.number.sum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Sum_Two {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] list = new int[3];
		
		System.out.println("Enter arrays values:");
		for(int i=0;i<3;i++) {
			list[i] = sc.nextInt();
		}
		
		System.out.println("Enter target value:");
		int target = sc.nextInt();
		
		System.out.println("Entered list");
		System.out.println(Arrays.toString(list));
		
		
		Sum_Two st = new Sum_Two();
		System.out.println("result");
		
		int [] arr1 = twoSum(list, target);	
		
		System.out.println(Arrays.toString(arr1));
	}
	
	public static int[] twoSum(int[] nums, int target) {
		
		int[] arr = new int[2];
		for(int i=0;i<nums.length-1;i++) {
			for(int j=i+1;j<nums.length;j++) {
			
				if(nums[i]+nums[j] == target) {
					arr[0] = i;
					arr[1] = j;
					
				}
				
			}
		}
		
		return arr;
		
	}
}
