package com.number.sum;

public class Reverse_Integer {

	public static void main(String[] args) {
		
		int x = 1534236469;
		
		Reverse_Integer ri = new Reverse_Integer();
		System.out.println(ri.reverse(x));
	}
	
	
	public int reverse(int x) {
		        int num = x;
		        long rev = 0;
		        while(num != 0){
		            int digit = num%10;
		            rev = 10*rev + digit;
		            if(rev > Integer.MAX_VALUE)return 0;
		            if(rev < Integer.MIN_VALUE)return 0;
		            num/=10;
		        }
		        return (int)rev;
		
		
	}
}
