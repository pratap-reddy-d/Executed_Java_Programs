package com.javapg.array;

import java.util.Arrays;
import java.util.Scanner;

public class Array_2D {

public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	int[][] arr1 = new int[2][];//colums not mandatory it takes both as 2
	int[][] arr = new int[2][3];
	
	
	System.out.println("Enter values");
	for(int i=0;i<arr.length;i++) { // arr[2][3] takes 2 becuase arr length is 2
		for(int j=0;j<arr[i].length;j++) { //arr[2][3] takes 3 because arr[2] length is 3
			System.out.println(arr.length);
			System.out.println(arr[i].length);
			arr[i][j] = sc.nextInt();
		}
	}
	
	for(int i=0;i<2;i++) {
		for(int j=0;j<3;j++) {
			System.out.print(arr[i][j]+" ");
		}
		System.out.println();
	}
	
	//anthoer way
	for(int i=0;i<arr.length;i++)
		 System.out.println(Arrays.toString(arr[i]));
	
}
}
