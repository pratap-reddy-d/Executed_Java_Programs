package com.javapg.array;

import java.util.Scanner;

public class Odd_eve_count {

	static Scanner sc = new Scanner(System.in);
	public static int[] arrayIndex(int size) {
		System.out.println("Enter the array elements:");
		int[] arr = new int[size];
		for(int i=0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		return arr;
	}
	
	
	public static void oddEvenCount(int[] arr) {
		int evencount = 0;
		int oddcount = 0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]%2==0)
				evencount++;
			else oddcount++;
		}
		
		System.out.println("Odd Numbers :"+oddcount+"\nEven Numbers :"+evencount);
	}
	
	
	public static void ElementsCountGreatthanAverage(int[] arr) {
		
		int avg = 0,count=0;
		for(int e : arr ) {
			avg = avg+e;
		}
		
		avg = avg/arr.length;
		for(int e : arr) {
			if(e>avg) count++;
		}
		
		System.out.println("The count of numbers more than average is:"+count);
		
	}
	
	public static void primeNumber(int a) {
		int count=0;
		
		for(int i=1;i<=a;i++) {
			if(a%i==0)
			count++;
		}
		
		if(count <= 2) System.out.println(a);
	}
	
	public static void PrimeNUmbercount(int[] arr) {
		System.out.println("Prime numbers are: ");
		for(int x : arr) {
			primeNumber(x);
		}
		
	}
	
	public static void MajorityElementRepeted(int[] arr) {
		
		
		for(int i=0;i<arr.length;i++) {
			int count = 0;	
			for(int j=i;j<arr.length;j++) {
				if(arr[i]==arr[j]) {
					count++;
				}
			}
			if(count > arr.length/2) {
				System.out.println(arr[i]);
			}
			else {
				System.out.println("No majority element.");
			}
		}
	}
	
	public static void ElementApprear2times(int[] arr) {
		
		for(int i=0;i<arr.length;i++) {
			int count =0;
			for(int j=0;j<arr.length;j++) {
				if(arr[i]==arr[j]) {
					count++;
				}
			}
			if(count == 2) {
				System.out.println(arr[i]);
			}
		//	else System.out.println("No element found");
		}
		
	}
	
	public static void UniqueElements(int[] arr) {
		
		for(int i=0;i<arr.length;i++) {
			int count =0;
			for(int j=0;j<arr.length;j++) {
				if(arr[i] == arr[j]) {
					count ++;
				}
			}
			if(count == 1) {
				System.out.println(arr[i]);
			}
		}
	}
	
	public static void DuplicateElements(int[] arr) {
		
		for(int i=0;i<arr.length;i++) {
			int count =0;
			for(int j=0;j<arr.length;j++) {
				if(arr[i] == arr[j]) {
					count ++;
				}
			}
			if(count > 1) {
				System.out.println(arr[i]);
			}
		}
		
	}
	

public static void ElementFound(int[] arr) {
	
	System.out.println("Enter the element to seach: ");
	int e = sc.nextInt();int c=0;
	
	for(int i=0;i<arr.length;i++) {
		if(e == arr[i]) {
			c++;
			System.out.println("Element found at index"+ i);
		}
	}
	if(c==0) System.out.println("Eelement not found");
}
	

public static void medianOfsortedArr(int[] arr) {
	
	int l = arr.length;
	double m = 0;
	
	if(l%2==0) {
		
	m=	arr[l/2]+arr[l/2-1];
	m=m/2;
	}
	else m=arr[l/2];
	
	System.out.println("Median is "+m);
	
}

public static void findEvenandOddPositionElement(int[] arr) {
	System.out.println("Odd numbers");
	for(int i=0;i<arr.length;i++) {
		if(i%2==0) {
			System.out.print(arr[i]);
		}
	}
	System.out.println("\nEven numbers");
		for(int i=0;i<arr.length;i++) {
			if(i%2!=0) {
				System.out.print(arr[i]);
		}
	}
}
	
public static void MaxElement(int[] arr) {
	int max = arr[0];
	
	for(int i=0;i<arr.length;i++) {
		if(max < arr[i]) {
			max = arr[i];
		}
	}
	System.out.println("max element "+max);
	}

public static void MinElement(int[] arr) {
	int max = arr[0];
	
	for(int i=0;i<arr.length;i++) {
		if(max > arr[i]) {
			max = arr[i];
		}
	}
	System.out.println("min element "+max);
	}

	public static void ElementFrequencyAppreance(int[] arr) {
		
		
	}



	public static void main(String[] args) {
		
	//	System.out.println("Enter the array size:");
	//	int size = sc.nextInt();
		//int[] arr =arrayIndex(size);
	//	oddEvenCount(arr);
		
	//	ElementsCountGreatthanAverage(arr);
		
		int[] arr1 = {1, 2, 3, 4, 5,8,5,6,5,7};
	//	PrimeNUmbercount(arr1);
		

	//	MajorityElementRepeted(arr1);
		
	//	ElementApprear2times(arr1);
		
	//	UniqueElements(arr1);
		
	//	DuplicateElements(arr1);
		
	//	ElementFound(arr1);
		
	//	medianOfsortedArr(arr1);
		
	//	findEvenandOddPositionElement(arr1);
		
	//	MaxElement(arr1);
		
	//	MinElement(arr1);
		
		ElementFrequencyAppreance(arr1);
		
	}
	
	
}
