package com.javapg.array;

import java.util.*;
import java.util.Scanner;

public class Array_single {
public static void main(String_Array[] args) {
	Scanner sc = new Scanner(System.in);
	
	int[] arr = {1,2,3,4,5};
	
	System.out.println(arr[0]);//arr[1] arr[2] arr[3] arr[4]
	
	int[] arr1;
	arr1 = new int[5];
	arr1[0] = 1;
	arr1[1] = 2;
	arr1[2] = 3;
	arr1[3] = 4;
	arr1[4] = 5;
	
	for(int i=0;i<arr1.length;i++) { // .length for arrays size 
		System.out.println(arr1[i]);
	}
	
	int[] arr2 = new int[5];//array declaration same as object creation
	System.out.println("Enter");
	for(int i=0;i<=4;i++) {
		arr2[i] = sc.nextInt();
	}
	
	for(int num:arr2) { //enhanced loop
		System.out.println(num);
	}
	
	System.out.println(Arrays.toString(arr)); // toString method for printing array as object  in string format
	
}
}
