package com.javapg.array;

import java.util.Arrays;

public class Array_minValue {

	public static void main(String[] args) {
		
		int[] arr = {71,85,61,51,41,31,21,11,1};
		
		int length = arr.length;
		
		int mid = length/2;
		
		//minvalue
		for(int j=0;j<arr.length-1;j++) {
			for(int i=0;i<arr.length-1;i++) {
				if(arr[i] > arr[i+1]) {
					int temp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = temp;
				}
			}
		}
		
		
		
		/*
		//max value
		
		int max;
		for(int j=0;j<arr.length-1;j++) {
			if(arr[j] < arr[j+1]) {
				max = arr[j+1];
				System.out.println(max);
			}
		}*/
		
		System.out.println(Arrays.toString(arr));
	}
}
