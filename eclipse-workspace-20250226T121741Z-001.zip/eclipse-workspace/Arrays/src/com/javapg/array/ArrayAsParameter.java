package com.javapg.array;

import java.util.Scanner;

public class ArrayAsParameter {
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	
	int[] arr = new int[5];
	System.out.println("Enter values");
	for(int i=0;i<arr.length;i++) {
		arr[i] = sc.nextInt();
	}
	
	m1(arr);
}

static void m1(int arr[]) {
	System.out.println("values are");
	for(int i=0;i<arr.length;i++)
	System.out.println(arr[i]);
}
}
