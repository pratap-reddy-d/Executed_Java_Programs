package com.javapg.array;

import java.util.Arrays;
import java.util.Scanner;

public class Array_swap {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int[] arr = {1,2,3,4,5,6};
	/*	
		System.out.println("Enter first index to swap");
		int i1 = sc.nextInt();
		System.out.println("Enter second index to swap");
		int i2 = sc.nextInt();
		
	System.out.println(swap(arr,i1,i2));
	int s1=0;
	int s2=arr.length-1;
	System.out.println(swap(arr,s1,s2));
	*/
		
		//reverse complete
		int arr1[] = new int[arr.length];
		
		for(int j=0,i=arr.length-1;i>=0;i--,j++) {
			arr1[j] = arr[i];
		}
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.toString(arr1));
	}
/*
	public static String swap(int[] arr,int i1,int i2) {
		
		int[] arr1 = arr;
		int temp = arr[i1];
		arr[i1] = arr[i2];
		arr[i2] = temp;
		
		return ""+Arrays.toString(arr1);
	}
	*/
}
