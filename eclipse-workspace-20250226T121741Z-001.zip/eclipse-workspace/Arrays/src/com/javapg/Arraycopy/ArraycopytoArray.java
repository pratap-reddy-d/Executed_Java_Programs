package com.javapg.Arraycopy;

import java.util.Arrays;

public class ArraycopytoArray {

	public static void copy(int[] arr) {
		int[] arr1 = arr;
		
		for(int x : arr1)
		System.out.println(x);
		
		int[] arr2 = Arrays.copyOf(arr1, arr1.length);
	}
	
	public static void OddEveSepCopy(int[] arr) {
		
		int[] odd = new int[arr.length];
		for(int i=0,j=0;i<arr.length;i++) {
			
			if(arr[i]%2!=0) {
				odd[j] = arr[i];
				j++;
			}
		}
		
		System.out.println("Odd elements array");
		for(int i=0;i<odd.length;i++) {
			if(odd[i]!=0) System.out.print(odd[i]+" ");
		}
		
		int[] eve = new int[arr.length];
		for(int i=0,j=0;i<arr.length;i++) {
			
			if(arr[i]%2==0) {
				eve[j] = arr[i];
				j++;
			}
		}System.out.println("\nEven elements array");
		for(int i=0;i<eve.length;i++) {
			if(eve[i]!=0) System.out.print(eve[i]+" ");
		}
	}
	
	
	public static void frequencyOccurence(int[] arr) {
		
		int[] ar1 = new int[arr.length];
		
		for(int i=0;i<arr.length;i++) {
		//	if(arr[i] == )
		}
		
	}
	
	public static void main(String[] args) {
		
		int[] arr = {1,2,3,4,5,6,7};
		
		OddEveSepCopy(arr);
	}
}
