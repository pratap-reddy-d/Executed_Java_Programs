package com.javapg.Arraycopy;

import java.util.Arrays;

public class SameElemInTwoArrayCopy {

	public static void copyArr(int[]arr,int[]arr1) {
		
		int[] newArr = new int[arr.length+arr1.length];
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr1.length;j++) {
				
				if(arr[i] == arr1[j]) {
					newArr[i] = arr[i];
				}
			}
		}
		for(int i=0;i<newArr.length;i++) {
			if(newArr[i]!=0)
				System.out.println(newArr[i]);
		}
		
	}
	
	public static int[] rightShift(int[] arr) {
		
		for(int j=0;j<arr.length;j++) {
		for(int i=0;i<arr.length-1;i++) {
			if(arr[i] == 0) {
				int temp = arr[i];
				arr[i] = arr[i+1];
				arr[i+1] = temp;
			}
		}
		}
		return arr;
		
	}
		public static void main(String []args) {
			
			int[] arr = {1, 2, 3, 4, 5};
			int[] arr1 = {3, 4, 5,3, 4};
			
			copyArr(arr,arr1);
		}
	
}
