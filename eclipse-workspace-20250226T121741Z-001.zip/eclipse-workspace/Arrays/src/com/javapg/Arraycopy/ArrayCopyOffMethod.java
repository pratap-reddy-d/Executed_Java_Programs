package com.javapg.Arraycopy;

import java.util.Arrays;

public class ArrayCopyOffMethod {
	
	
	public static void AddOddEle(int[] arr) {
		
		int[] odd = new int[arr.length];
		for(int i=0,j=0;i<arr.length;i++) {
			
			if(arr[i]%2!=0) {
				odd[j] = arr[i];
				j++;
			}
		}
		
		System.out.println("Odd elements array");
		for(int i=0;i<odd.length;i++) {
			if(odd[i]!=0) System.out.print(odd[i]+" ");
		}
		
		int[] eve = new int[arr.length];
		for(int i=0,j=0;i<arr.length;i++) {
			
			if(arr[i]%2==0) {
				eve[j] = arr[i];
				j++;
			}
		}System.out.println("\nEven elements array");
		for(int i=0;i<eve.length;i++) {
			if(eve[i]!=0) System.out.print(eve[i]+" ");
		}
	}
public static void main(String[] args) {
	
	int[] arr1 = {1,2,3,4,5,6,7};
	
	int[] arr2 = new int[10];
	
	
	AddOddEle(arr1);
//	
//	arr2 = Arrays.copyOf(arr1,arr1.length);
//	
//	System.out.println(Arrays.toString(arr1));
//	System.out.println(Arrays.toString(arr2));
}
}
