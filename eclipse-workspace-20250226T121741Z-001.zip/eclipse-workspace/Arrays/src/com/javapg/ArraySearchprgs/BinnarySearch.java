package com.javapg.ArraySearchprgs;

public class BinnarySearch {
	
	public static void Binarysearch(int[] arr,int ele) {
		
		int mid = arr.length/2;
		int count = 0;
		
		if(ele < arr[mid]) {
			for(int i=0;i<mid;i++) {
				if(ele == arr[i]) {
					count++;
					System.out.println("Element found at index: "+i);
				}
			}
		}
		
		if(ele > arr[mid]) {
			for(int i=mid;i<arr.length;i++) {
				if(ele == arr[i]) {count++;
					System.out.println("Element found at index: "+i);
				}
			}
		}
		if(ele == arr[mid]) { count++;
			System.out.println("element found at index"+mid);
		}
		
		if(count == 0) System.out.println("Element not found.");
	}

	
	public static int BinaryserachIndex(int[] arr,int ele) {
		
		int start = 0;
		int end = arr.length-1;
				
		while(start <= end) {
			int mid = (start+end)/2;
			int midEle = arr[mid];
			
			 if(ele == midEle) {
				 return mid;
			}
			else if(ele > midEle) {
				start = mid+1;
			}
			else {
				end = mid-1;
			}
		}
		
		return -1;
		//System.out.println(start+""+end+""+mid);
		
	}
	
	public static void main(String[] args) {
		
		int[] arr = {1,2,3,4,5,6,8};
		int ele = 6;
		
		Binarysearch(arr,ele);
		
	int ind = BinaryserachIndex(arr,ele);
	
	if (ind != -1) {
		System.out.println("Element found at index " + (ind+1));
	} else {
		System.out.println("Not found");
	}
	}
}
