package com.javapg.ArraySearchprgs;

public class BSusingIndex {
	
	public static int BinarySearch(int[] arr,int ele,int start1,int end1) {
		
		int start = start1;
		int end = end1;
		
		while(start!=end) {
			int mid = (start+end)/2;
			int midEle = arr[mid];
			
			if(midEle == ele) {
				return mid;
			}
			else if(ele > midEle) {
			start = mid+1; 
			}
			else if(ele< midEle) {
				end = mid-1;
			}
			
		}
		return -1;
		
	}

	public static void IndexedBS(int[] arr,int first,int second){
		
//		for(int i=0;i<arr.length;i++) {
//			
//		}
	}
	
	
	
	public static void main(String[] args) {
		int[] arr = {1,2,3,4,5,6,7,8,9};
		
		
	int v =	BinarySearch(arr,5,3,6);
		
	if(v==-1) System.out.println("element not found");
	else System.out.println("Element found at index :"+v);
	}
}
