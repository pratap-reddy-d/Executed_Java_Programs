package com.emp.trie;

public class Emptyu {

	public static void main(String[] args) {
		Empty.y(12);
		Max.z(34);
	}
}
