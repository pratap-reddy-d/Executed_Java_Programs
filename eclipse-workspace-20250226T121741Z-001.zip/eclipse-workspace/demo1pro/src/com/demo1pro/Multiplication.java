package com.demo1pro;

public class Multiplication {
	int x=10;
	static int y =20;
	public static void main(String[] args) {
		
		
		Multiplication m = new Multiplication();
		m.x=100;
		m.y=200;
		System.out.println(m.x+"---"+m.y);
		Multiplication m1 = new Multiplication();
		m1.x=100;
		m1.y=200;
		System.out.println(m1.x+"--"+m1.y);
	}
}
