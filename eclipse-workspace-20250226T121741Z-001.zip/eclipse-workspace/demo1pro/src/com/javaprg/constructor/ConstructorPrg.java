package com.javaprg.constructor;

public class ConstructorPrg {
	
	public ConstructorPrg(int a, int b, int c) {
		System.out.println(a+b+c);
		return;
	}

	static int m1= 10;
	public static void main(String[] args) {
		
	final int m = 10;
		ConstructorPrg co = new ConstructorPrg(11,23,43);
		
		System.out.println(co);
	}
}
