package com.javapg.itc;

public class Account {

	private int balance = 0; //1000
	
	public synchronized void withdraw(int amount) { //100
		
		while(balance < amount) {
			try {
				
				wait();
			}
			catch(InterruptedException e) {
				System.out.println("Balance low");
			}
		}
		
		this.balance = balance - amount ;
		
		System.out.println("withdraw amount is "+amount+" Updated balance is after wihtdraw:"+ balance);
		
		notify();
	}
	
	public synchronized void deposit(int amount) {
		
		this.balance = balance + amount;
		
		System.out.println("deposited balance is:"+balance);
		
		notify();
		
	}
	
	
}
