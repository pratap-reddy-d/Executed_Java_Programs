package com.javapg.itc;

public class ATMmachine {

	public static void main(String[] args) throws InterruptedException {
		
		Account account = new Account();
		Depositor dep = new Depositor(account);
		
		Drawer draw = new Drawer(account);
		
		Thread t = new Thread(dep);
		
		Thread t1 = new Thread(draw);
		
	
		t.start();	
		
		t1.start();	
		
	}
}
