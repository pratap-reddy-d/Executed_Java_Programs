package com.javapg.covid19;

public class DoseBooking {

	private boolean booked = false;
	
	public void bookDose() {
		if(booked) {
			throw new RuntimeException("Dose already booked.");
		}
		booked = true;
	}
	
	public boolean  isDoseBooked() {
		
		return booked;
	}
}
