package com.javapg.covid19;

public class User {

	private String name;
	
	
	private VaccineEligibility eligibility;
	
	private DoseBooking doseBooking;

	public User(String name, int age, boolean hasHealthCondition) {
		super();
		this.name = name;
		this.eligibility = new VaccineEligibility(age,hasHealthCondition);
		this.doseBooking = new DoseBooking();
	}
	
	public void isEligible(){
		if(eligibility.isEligible()) {
			throw new RuntimeException(name+"is not eligible for the vaccine.");
		}
	}
	
	public void bookDose() {
		if(eligibility.isEligible()) {
			throw new RuntimeException(name+"is not eligible for the vaccine.");
		}
		doseBooking.bookDose();
		System.out.println("Dose booked succeddfully for"+name);
	}
	
	public boolean isDoseBooked() {
		return doseBooking.isDoseBooked();
	}
}
