package com.javapg.covid19;

public class CoronaVaccineApp {
	
public static void main(String[] args) {

	User user1 = new User("ramesh", 21, true);
	User user2 = new User("suresh", 67, false);
	
	Thread thread1 = new Thread() {
		@Override
		public void run() {
			try {
				user1.isEligible();
				user1.bookDose();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
	};
	
	Thread thread2 = new Thread() {
		@Override
		public void run() {
			try {
				user2.isEligible();
				user2.bookDose();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
		}
	};
	
	thread1.start();
	thread2.start();
}	
}
