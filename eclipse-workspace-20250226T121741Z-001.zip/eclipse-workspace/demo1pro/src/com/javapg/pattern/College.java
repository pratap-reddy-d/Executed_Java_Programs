package com.javapg.pattern;

class student {
	int sno;
	String sname;
	String course;
	    double fee;
	
}
	class College{
	    public static void main(String[]args)
	    		{
	       student s1 = new student();
	       student s2 = new student();
	    		
	        s1.sno =101;
	        s1.sname="Arun";
	        s1.course="javs";
	        s1.fee=5000;

	        s2.sno=101;
	        s2.sname="suma";
	        s2.course ="javs";
	        s2.fee =6000;

	        System.out.println("s1 object value");
	        System.out.println("s1 sno:\t"+s1.sno);
	        System.out.println("s1 sname:\t"+s1.sname);
	        System.out.println("s1 course:\t"+s1.course);
	        System.out.println("s1 fee:\t"+s1.fee);

	        System.out.println("s2 object value");
	        System.out.println("s2 sno:\t"+s2.sno);
	        System.out.println("s2 sname:\t"+s2.sname);
	        System.out.println("s2 course:\t"+s2.course);
	        System.out.println("s2 fee:\t" + s2.fee);
			    
	       
	    	}		    
	}