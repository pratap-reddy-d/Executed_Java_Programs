package com.javapg.educourseenrolsystem;

public class Course {

	int courseid;
	String courseName;
	double courseFee;
	public Course(int courseid, String courseName, double courseFee) {
		super();
		this.courseid = courseid;
		this.courseName = courseName;
		this.courseFee = courseFee;
	}
	public int getCourseid() {
		return courseid;
	}
	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public double getCourseFee() {
		return courseFee;
	}
	public void setCourseFee(double courseFee) {
		this.courseFee = courseFee;
	}
	@Override
	public String toString() {
		return "CourseBlc [courseid=" + courseid + ", courseName=" + courseName + ", courseFee=" + courseFee + "]";
	}
	
	
}
