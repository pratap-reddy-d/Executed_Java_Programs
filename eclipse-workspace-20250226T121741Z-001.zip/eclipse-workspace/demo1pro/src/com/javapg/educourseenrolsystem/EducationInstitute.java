package com.javapg.educourseenrolsystem;

public class EducationInstitute {

	Course[] courses;
	Offer[] offer;
	
	public EducationInstitute(Course[] courses, Offer[] offer) {
		super();
		this.courses = courses;
		this.offer = offer;
	}
	
	Course[] getCourses(){
		return courses;
	}
	
	Offer[] getOffers(){
		return offer;
	}
	
	public void enrollStudentInCourse(int courseId, String studentName){
		System.out.println(studentName+"Enrolled in a course");
	}
}
