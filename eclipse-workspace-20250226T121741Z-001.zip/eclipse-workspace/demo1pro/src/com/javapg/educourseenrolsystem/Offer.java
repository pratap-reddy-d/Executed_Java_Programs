package com.javapg.educourseenrolsystem;

public class Offer {

	String offerText;
	
	public Offer(String offerText){
		this.offerText = offerText;
	}
	
	public String getOfferText(){
	return	offerText;
	}
	
}
