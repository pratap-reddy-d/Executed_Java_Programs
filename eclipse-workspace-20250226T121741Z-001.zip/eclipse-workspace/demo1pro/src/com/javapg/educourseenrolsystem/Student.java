package com.javapg.educourseenrolsystem;

public class Student {

	String name;
	EducationInstitute institute;
	
	public Student(String name, EducationInstitute institute) {
		super();
		this.name = name;
		this.institute = institute;
	}

	public void viewCoursesAndFees(){
		System.out.println(institute.getCourses());
	}
	
	public void viewOffers(){
		System.out.println("Ongoing offers"+institute.getOffers());
	}
	
	int enrollInCourse(int courseId){
		return courseId;
		
	}
}
