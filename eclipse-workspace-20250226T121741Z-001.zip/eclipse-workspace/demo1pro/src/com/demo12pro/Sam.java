package com.demo12pro;

@FunctionalInterface
interface NIT{
	//public int myInterface(int b);
	//public int myInterface(int a, int b);
	int myInterface(int a);
}

class Sam{
	public static void main(String[] args) {
	//	int a = 2,x=3;
			
	//	NIT nit = (int a) -> System.out.println(a+5);
	/*	
		NIT nit = (b) -> a+1;
		System.out.println(nit.myInterface(a));
		
		NIT nt = new NIT(){
			@Override
			public int myInterface(int b) {
				int a = b*b*b;
				return a;
			}
		};
		
		System.out.println(nt.myInterface(x));
		*/
		
	}
	
}