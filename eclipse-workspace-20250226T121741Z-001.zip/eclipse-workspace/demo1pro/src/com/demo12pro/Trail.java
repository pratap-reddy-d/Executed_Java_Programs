package com.demo12pro;

public class Trail{
	public static void main(String[] args) {
		
		String s1 = "reddy";
		int n1 = 20;
		
		Man m = new Man();
		System.out.println(m);
	}
}