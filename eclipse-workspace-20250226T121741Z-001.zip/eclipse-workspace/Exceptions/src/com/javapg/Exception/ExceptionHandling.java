package com.javapg.Exception;

public class ExceptionHandling {

	public static void main(String[] args){
		System.out.println("main start");
		
			m1();
		
		System.out.println("main end");
		
	}
	public static void m1() {
		System.out.println("m1 start");
		try {System.out.println(10/0);	}
		catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("m1 end");
	}
}
