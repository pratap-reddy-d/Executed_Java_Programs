package com.javapg.Exception;

public class CheckedException {

	public static void main(String[] args) {
		
		System.out.println(10/0);
	}
}
