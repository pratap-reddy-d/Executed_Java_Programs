package com.javapg.Threadex2;

public class MyData extends Thread{

	private boolean request;
	private String data;
	public void run() {
		
		storeMessage("Hello");
		String str = retrieveMessage();
		System.out.println(str);
	}
	
	private synchronized void storeMessage(String data) {
		request = true;
		this.data = data;
	}
	private synchronized String retrieveMessage() {
		request = false;
		return data+" : "+request; 
	}
}
