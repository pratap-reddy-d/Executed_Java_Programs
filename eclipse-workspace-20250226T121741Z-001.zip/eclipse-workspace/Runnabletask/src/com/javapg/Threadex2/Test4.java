package com.javapg.Threadex2;

public class Test4 {

	public static void main(String[] args) {
		MyData md = new MyData();
		md.start();
	}

}
