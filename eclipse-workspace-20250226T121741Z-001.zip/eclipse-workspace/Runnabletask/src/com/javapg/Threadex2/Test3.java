package com.javapg.Threadex2;

public class Test3 {

	public static void main(String[] args) {
		
		Job thread = new Job();
		
		thread.start();
		
		try {
			thread.join();
		}
		catch(Exception e) {
			
		}
		System.out.println(thread.getNumber());
	}

}
