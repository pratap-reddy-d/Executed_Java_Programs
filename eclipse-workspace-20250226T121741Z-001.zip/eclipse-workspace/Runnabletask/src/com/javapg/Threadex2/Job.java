package com.javapg.Threadex2;

public class Job extends Thread {

	private Integer number = 0;
	
	public void run() {
		
		for(int i=1;i<1000000;i++) {
			number++;
		}
	}
	public Integer getNumber() {
		return number;
	}
}