package com.javapg.Threadex2;

public class Test9 {

	public static void main(String[] args) {
		
		MyThread9 obj1 = new MyThread9("Cut the ticket");
		MyThread9 obj2 = new MyThread9("Show the seat");
		
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		
		t1.start();
		t2.start();

	}

}
