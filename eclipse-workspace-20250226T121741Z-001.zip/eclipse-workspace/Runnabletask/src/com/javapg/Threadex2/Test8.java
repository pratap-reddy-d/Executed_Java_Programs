package com.javapg.Threadex2;

public class Test8 {

	public static void main(String[] args) {

		try {
			MyThread8 mt1 = new MyThread8("mt1");
			MyThread8 mt2 = new MyThread8("mt2");
			mt1.start();
			mt1.join();
			mt2.start();
		}
		catch(Exception e) {
			
		}
	}

}
