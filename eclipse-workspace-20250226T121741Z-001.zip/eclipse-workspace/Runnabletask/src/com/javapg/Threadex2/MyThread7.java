package com.javapg.Threadex2;

public class MyThread7 extends Thread {

	public void run() {
		System.out.println("MyThread: run()");
	}
	public void start() {
		System.out.println("MyThread : start()");
	}
}
