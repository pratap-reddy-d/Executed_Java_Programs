package com.javapg.Threadex2;

public class Test7 {

	public static void main(String[] args) {
	
		MyThread7 myThread = new MyThread7();
		
		MyRunnable7 myRunnable = new MyRunnable7();
		
		Thread thread = new Thread(myRunnable);
		myThread.start();
		thread.start();
	}

}
