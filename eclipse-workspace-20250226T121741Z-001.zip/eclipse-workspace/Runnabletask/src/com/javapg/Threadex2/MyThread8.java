package com.javapg.Threadex2;

public class MyThread8 extends Thread{

	String myName;
	
	MyThread8(String name){
		myName = name;
	}
	
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println(myName);
		}
	}
}
