package com.javapg.MediachatProcess;

public class InstagramChatTest {

	public static void main(String[] args) {
		
		 InstagramUser instagramUser = new InstagramUser("John");

	        // Create an InstagramChat object
	        InstagramChat instagramChat = new InstagramChat();

	        // Demonstrate sending a message through InstagramChat
	        instagramChat.sendMessage(instagramUser);  // Should successfully send the direct message

	        // Create a non-InstagramUser object
	        User nonInstagramUser = new User("Alice");

	        // Try to send a message using the same InstagramChat object
	        instagramChat.sendMessage(nonInstagramUser); 
	}

}
