package com.javapg.MediachatProcess;

public class InstagramChat implements Messanger{

	@Override
	public void sendMessage(User user) {
		if (user instanceof InstagramUser) {
            InstagramUser instagramUser = (InstagramUser) user;
            // Use the InstagramUser specific method
            instagramUser.sendDirectMessage("Hello from Instagram!");
        } else {
            // If the user is not an InstagramUser, throw an error message
            System.out.println("Error: User is not an Instagram user.");
        }
		
	}

}
