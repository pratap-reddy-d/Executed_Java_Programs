package com.javapg.MediachatProcess;

public class User {

	private String name;

	public User(String name) {
		super();
		this.name = name;
	}
	
	public void displayMessage(String message) {
	System.out.println("User "+name);	
	System.out.println("Message"+message);
	}
}
