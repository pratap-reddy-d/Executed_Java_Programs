package com.javapg.MediachatProcess;

public class InstagramUser extends User{

	public InstagramUser(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public void sendDirectMessage(String message) {
		System.out.println("Sending direct message on Instagram: " + message);
	}
}
