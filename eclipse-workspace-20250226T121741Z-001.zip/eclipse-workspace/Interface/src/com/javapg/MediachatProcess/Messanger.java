package com.javapg.MediachatProcess;

public interface Messanger {

	abstract public void sendMessage(User user);
}
