package com.javapg.mediaPlayer;

public interface AdvancedmediaPlayer extends MediaPlayer {

	public void pause();
}
