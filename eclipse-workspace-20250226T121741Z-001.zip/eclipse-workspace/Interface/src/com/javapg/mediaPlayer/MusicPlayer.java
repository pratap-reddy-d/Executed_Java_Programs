package com.javapg.mediaPlayer;

public class MusicPlayer implements AdvancedmediaPlayer{

	String title = null;
	
	public MusicPlayer(String title) {
		if(title == "")
		System.err.println("Error: title must not be empty!"); 
		else this.title = title;
	}
	
	@Override
	public void play() {
		System.out.println("Playing music	: "+title);
		
	}

	@Override
	public void stop() {
		System.out.println("Pausing music	: "+title);
		
	}

	@Override
	public void pause() {
		System.out.println("Stopping music	: "+title);
		
	}

	
}
