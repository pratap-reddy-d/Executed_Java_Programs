package com.javapg.mediaPlayer;

public abstract interface MediaPlayer {

	abstract public void play();
	
	abstract public void stop();
}
