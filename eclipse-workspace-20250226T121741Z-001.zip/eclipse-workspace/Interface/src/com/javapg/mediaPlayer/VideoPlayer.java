package com.javapg.mediaPlayer;

public class VideoPlayer implements AdvancedmediaPlayer {

	String title;
	
	public VideoPlayer(String title) {
		this.title = title;
	}
	
	@Override
	public void play() {
		System.out.println("Playing music	: "+title);
		
	}

	@Override
	public void stop() {
		System.out.println("Pausing music	: "+title);
		
	}

	@Override
	public void pause() {
		System.out.println("Stopping music	: "+title);
		
	}

}
