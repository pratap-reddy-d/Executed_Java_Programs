package com.javapg.Calculator;

public interface Calculator {

	abstract public void calculateSum(int ...num);
}
