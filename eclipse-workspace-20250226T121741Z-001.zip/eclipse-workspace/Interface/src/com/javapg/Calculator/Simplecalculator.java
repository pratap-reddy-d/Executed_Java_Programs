package com.javapg.Calculator;

public class Simplecalculator implements Calculator {

	int sum =0;

	@Override
	public void calculateSum(int... num) {
		
		for(int n1 : num) {
			sum+=n1;
		}
		
		System.out.println("\"Sum of the numbers: "+sum+"\"");
	}

}
