package com.spynumber;

import java.util.Scanner;

public class CheckSpyElc {

	public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number:");
		int n = sc.nextInt();
				
		CalculateBlc.checkSpyNum(n);
		sc.close();
	}

}
