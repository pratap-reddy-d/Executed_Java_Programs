package com.javaprg.abstraction;

import java.util.Scanner;

public class BattingTest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

	//	String name = sc.nextLine();
	//	int runs = sc.nextInt();
	//	int matches = sc.nextInt();
		
		Batter bt = new Batter("sachin",18000,463);
		System.out.println(bt.getStatistics());
		
		System.out.println(bt);
		
		sc.close();
		
	}

}
