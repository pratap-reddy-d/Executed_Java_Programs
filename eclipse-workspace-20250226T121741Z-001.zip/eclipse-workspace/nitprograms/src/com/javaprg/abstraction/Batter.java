package com.javaprg.abstraction;

public class Batter {

	String name;
	int runs;
	int matches;
	float batting_avg;
	
	public Batter() {
		
	}

	public Batter(String name, int runs, int matches) {
		super();
		if(name == " ") {
			System.err.println("Name cannot be empty");
		}
		
		else if(runs <= 0  ) {
			System.err.println("Error");
			System.err.println("Runs and matches must be non-negative");
		}
		else if(runs > 0 && matches <= 0) {
			System.err.println("Error");
		}
		
		else {
		
		this.name = name;
		this.runs = runs;
		this.matches = matches;
		}
		computerBattingAverage();
	}
	
	public void computerBattingAverage() {
		
		
		this.batting_avg = runs / matches;
	}
	
	public String getStatistics() {
		return "Batter [name=" + name + ", runs=" + runs + ", matches=" + matches
				+ "]";
	}

	@Override
	public String toString() {
		return "Batter [name=" + name + ", batting_avg=" + batting_avg + "]";
	}

	
	
	
	
}
