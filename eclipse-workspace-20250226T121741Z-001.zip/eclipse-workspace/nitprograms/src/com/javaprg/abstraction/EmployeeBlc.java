package com.javaprg.abstraction;

public class EmployeeBlc {

private	String firstName;
private	String lastName;
private	int employeeId;
private	double salary;
private	int noOfProject;

public EmployeeBlc(String firstName, String lastName, int employeeId, double salary, int noOfProject) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.employeeId = employeeId;
	this.salary = salary;
	this.noOfProject = noOfProject;
}
	
	public void calculateSalary() {
		
		if(noOfProject <= 0) {
			System.err.println("Invalid Number of the projects (Negative Value)");
		}
	   else if(noOfProject > 5 && noOfProject < 10) {
			this.salary = salary+5000;
		}
		else if(noOfProject > 10 && noOfProject < 20) {
			this.salary = salary+10000;
		}
		else if(noOfProject > 20) {
			this.salary = salary+15000;
		}
		
		
		if(noOfProject <= 0) {
			System.out.println(" Salary remains : "+salary);
		}
		
		else {
			System.out.println("Updated salary :" +salary);
		}
	}

	@Override
	public String toString() {
		return "EmployeeBlc [firstName=" + firstName + ", lastName=" + lastName + ", employeeId=" + employeeId
				+ ", salary=" + salary + ", noOfProject=" + noOfProject + "]";
	}
}
