package com.javaprg.toStringprgs;

import java.util.Scanner;

public class TesterStudent {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter student id:");
		int studentId = sc.nextInt();
		
		System.out.println("Enter student name:");
		sc.nextLine();
		String studentName = sc.nextLine();
		
		
		System.out.println("Enter student marks:");
		int marks = sc.nextInt();
		
		Student st = new Student();
		
		st.setStudentData(studentId, studentName, marks);
		st.calculateGrade();
		System.out.println(st.toString());
		
		sc.close();
	}

}
