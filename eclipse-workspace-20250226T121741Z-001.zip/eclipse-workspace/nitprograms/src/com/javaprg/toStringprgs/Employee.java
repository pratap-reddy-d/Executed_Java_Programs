package com.javaprg.toStringprgs;

public class Employee {

	private String firstName;
	private String lastName;
	private int employeeId;
	private double salary;
	private int noOfProject;
	
	public void setEmployeeData(String firstName, String lastName, int employeeId,
	 double salary,int noOfProject) {
		
		this.firstName = firstName;
		this.employeeId = employeeId;
		this.lastName = lastName;
		this.noOfProject = noOfProject;
		this.salary= salary;
	}
	
	public void calculateSalary() {
		
		if(noOfProject >5 && noOfProject < 10) {
			salary = salary+5000;
		}
		else if(noOfProject > 10 && noOfProject < 20) {
			salary = salary+10000;
		}
		else if(noOfProject > 20) {
			salary = salary+15000;
		}
	}

	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", employeeId=" + employeeId
				+ ", salary=" + salary + ", noOfProject=" + noOfProject + "]";
	}
	
	
}
