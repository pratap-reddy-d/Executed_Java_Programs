package com.javaprg.toStringprgs;

import java.util.Scanner;

public class GetterandSetter {

	public static void main(String[] args) {
				
		Scanner sc = new Scanner(System.in);
		
		int marks = sc.nextInt();
		int rollno = sc.nextInt();
		sc.nextLine();
		String grade = sc.nextLine();
		
		Getter g = new Getter();
		
		g.setGrade(grade);
		g.setMarks(marks);
		g.setRollno(rollno);
		
		System.out.println(g.getMarks());
		System.out.println(g.getGrade());
		System.out.println(g.getRollno());
		
		sc.close();

	}

	
}
