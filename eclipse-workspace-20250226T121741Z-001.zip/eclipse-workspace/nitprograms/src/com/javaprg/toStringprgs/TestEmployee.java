package com.javaprg.toStringprgs;

import java.util.Scanner;

public class TestEmployee {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Employee First Name:");
		String firstName = sc.nextLine();
		
		System.out.println("Enter Employee Last Name:");
		String lastName = sc.nextLine();
		
		System.out.println("Enter Employee Id Number:");
		int employeeId = sc.nextInt();
		
		System.out.println("Enter Employee Salary :");
		double salary = sc.nextDouble();
		
		System.out.println("Enter Employee Number of projects:");
		int noOfProject = sc.nextInt();
		
		Employee emp = new Employee();
		
		emp.setEmployeeData(firstName, lastName, employeeId, salary, noOfProject);
		emp.calculateSalary();
		
		System.out.println(emp);
		
		sc.close();
	}

}
