package com.javaprg.toStringprgs;

public class Student {

	private int studentId;
	private String studentName;
	private int marks;
	private char grade;

	public void setStudentData(int studentId, String studentName, int marks) {
		
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
		
	}
	
    public void calculateGrade() {
		
    	if(marks >= 90) {
    		
    		grade = 'A';
    	}
    	else if(marks > 81 && marks < 90){
    		grade = 'B';
    	}
    	else if(marks > 71 && marks < 80){
    		grade = 'C';
    	}
    	else if(marks > 61 && marks < 70){
    		grade = 'D';
    	}
    	else if(marks < 61){
    		grade = 'E';
    	}
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", marks=" + marks + ", grade="
				+ grade + "]";
	}

   
		
	
}
