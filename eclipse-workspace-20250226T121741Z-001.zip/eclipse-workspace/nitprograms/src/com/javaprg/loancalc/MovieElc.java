package com.javaprg.loancalc;

import java.util.Scanner;

public class MovieElc {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Movie m = new Movie("tiger",2024,"voilence");
		
		m.setTitle("villan");
		System.out.println(m);
		sc.close();
	}

}
