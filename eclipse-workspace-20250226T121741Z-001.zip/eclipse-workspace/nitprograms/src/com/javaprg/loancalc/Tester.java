package com.javaprg.loancalc;

public class Tester {

	public static void main(String[] args) {
		
		Employee emp = new Employee( 0,"Naresh kumar",43000);

		System.out.println(emp);
		emp.getEmployeeSalary();
	}

}
