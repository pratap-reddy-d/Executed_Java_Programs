package com.javapg.employee;

public class MainElc {

	public static void main(String[] args) {
		

		Task t = new Task("Finish Project","Complete documentation","High");
		
		
		System.out.println(t);
		
		
	}

}
