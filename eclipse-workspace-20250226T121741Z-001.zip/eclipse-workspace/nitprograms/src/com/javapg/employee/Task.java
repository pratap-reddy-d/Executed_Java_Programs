package com.javapg.employee;

public class Task {

	private String title;
	private String description;
	private String priority;
	String task = "";
	
	public Task(String title, String description, String priority) {
		super();
		
		if(title != null) {
			this.title = title;
		}
		else {
			System.err.println("Error message indicating invalid title.");
		}
		
		if(description != null) {
		this.description = description;
		}
		else {
			System.err.println("Error message indicating invalid description.");	
		}
		if(priority != null)
		this.priority = priority;
		else System.err.println("Error message indicating invalid priority.");
	}
	
	public void updateDescription(String description) {
	this.description = description;	
	}
	
	public void updatePriority(String priority) {
		this.priority=  priority;
	}
	
	public String markAsCompleted() {
		task = "completed";
		return task;
	}
	
	public String getTitle() {
		
		if(this.title != null) {
			return this.title;
		}
		else 
		return "Error";
	}
	
	public String getDescription() {
		
		if(this.description != null) {
			return this.description;
		}
		else 
		return "Error";
		
	}
	
	public String  getPriority() {
		
		if(this.priority != null) {
			return this.priority;
		}
		else 
		return "error";
	}
	
	public boolean isCompleted() {
		
		 return this.task == "completed" ? true :  false;
	}

	@Override
	public String toString() {
		String x = "";
		if(title != null && description != null && priority != null) {
			x = "Task [title=" + title + ", description=" + description + ", priority=" + priority + ", task=" + isCompleted();
		}
		return x;
	}
	
	
}
