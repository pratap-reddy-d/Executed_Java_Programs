package com.javapg.GradeCalc_CopyConstructor;

public class Student {

	private String name;
	private int id;
	private String course;
	private double fee;
	private char grade;
	private double average;
	
	public Student(String name, int id, String course, double fee, double average) {
		super();
		this.name = name;
		this.id = id;
		this.course = course;
		this.fee = fee;
		if(average > 0)
		this.average = average;
		else System.err.println("Average mark must be between 0 and 100.");
	}

	public Student(Student stu) {
		
		this.name = stu.name;
		this.id = stu.id;
		this.course = stu.course;
		this.fee = stu.fee;
		this.average = stu.average;
		
	}
	
	public char calculateGrade() {
		
		if(this.average >= 90) {
			grade = 'A';
		}
		else if(this.average >= 80) {
			grade = 'B';
		}
		else if(this.average >= 70) {
			grade = 'C';
		}
		else if(this.average >= 60) {
			grade = 'D';
		}
		else{
			grade = 'F';
		}
		return grade;
	}

	@Override
	public String toString() {
		
			return "Grade for average "+this.average +" : " + calculateGrade();
	}
	
	
}
