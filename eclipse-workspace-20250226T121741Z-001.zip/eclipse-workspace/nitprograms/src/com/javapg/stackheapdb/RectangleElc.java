package com.javapg.stackheapdb;

public class RectangleElc {

	public static void main(String[] args) {
		
		Rectangle rect = new Rectangle(5,+10);
		
	double	r = rect.getArea();
	double p = rect.getPerimeter();
	
	if(r!=0 && p!=0) {
		System.out.println("Area: "+r); 
		System.out.println("perimeter: "+p);
	}
		

	}

}
