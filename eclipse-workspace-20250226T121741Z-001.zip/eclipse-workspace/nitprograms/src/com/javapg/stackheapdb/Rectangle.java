package com.javapg.stackheapdb;

public class Rectangle {

	
	private double width;
	private double height;
	
	public Rectangle(double width) {
		this.width = width;
	}
	
	public Rectangle(double width, double height) {
		super();
		
		if(width > 0 && height > 0 ) {
		this.width = width;
		this.height = height; }
		else System.err.println("Width and height must be non-negative.");
		
	}
	
	public double getArea() {
		double ans = this.width*this.height;
		return ans;
	}
	
	public double getPerimeter() {
		double ans = (this.width+this.height)*2;
		return ans;	
	}
	
}
