package com.javapgr.calulate;

public class Car extends Vehicle {

	public Car(double totalDistance, double totalFuelConsumed) {
		super(totalDistance, totalFuelConsumed);
		
	}

	public double calculateFuelEfficiency(double miles,double gallon) {
		return miles/gallon;
		
	}
	
	
}
