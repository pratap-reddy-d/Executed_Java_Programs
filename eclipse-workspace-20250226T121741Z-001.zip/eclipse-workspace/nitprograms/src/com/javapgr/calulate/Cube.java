package com.javapgr.calulate;

public class Cube extends Shape {

	@Override
        public double calculateVolume1(double sideLength) {
		double side = sideLength*sideLength*sideLength;
		return side;
	}

	
}
