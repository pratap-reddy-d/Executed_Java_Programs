package com.javapgr.calulate;

public class MainShape {

	public static void main(String[] args) {
	
		Cube c = new Cube();
		
		Cylinder cy = new Cylinder();
		
		Sphere sp = new Sphere();
		
		System.out.println("Volume of the Cube: "+c);
		
		System.out.println("Volume of the Cube: "+cy);
		
		System.out.println("Volume of the Cube: "+sp);
		
	}

}
