package com.javapgr.calulate;

public class Cylinder extends Shape{

public double calculateVolume(double radius, double height) {
		
		double side = 3.14*radius*radius*height;
		return side;
	}
}
