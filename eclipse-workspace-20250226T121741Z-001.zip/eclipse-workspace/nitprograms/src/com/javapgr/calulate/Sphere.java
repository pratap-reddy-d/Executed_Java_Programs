package com.javapgr.calulate;

public class Sphere extends Shape{

public double calculateVolume(double radius) {
		
		double side = 4/3*3.14*radius*radius;
		return side;
	}

}
