package com.javapgr.calulate;

public class MainElc {

	public static void main(String[] args) {
		
		Vehicle v = new Vehicle(12, 3);
		
		Car c = new Car(13,4);
		
	}

}
