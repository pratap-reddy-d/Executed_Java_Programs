package com.nitprograms;

public class NextMultipleOfHundred {

	public static int getNextMultipleOfHundred(int num) {
		int count = 0;
		for(int i=num;i!=0;i/=10) count = i; 		
		
		return ++count *100;
		
	}
}
