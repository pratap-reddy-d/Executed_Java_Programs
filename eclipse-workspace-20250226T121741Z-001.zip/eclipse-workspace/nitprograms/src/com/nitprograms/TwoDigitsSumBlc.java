package com.nitprograms;

public class TwoDigitsSumBlc {

	public static int getSumOfDigits(int num){		
		int sum = 0;
	
		for(int i=num; i!=0;i/=10) {
			int temp = i%10;
			
			sum = sum + temp;
		}
		
		return sum;
	}

}
