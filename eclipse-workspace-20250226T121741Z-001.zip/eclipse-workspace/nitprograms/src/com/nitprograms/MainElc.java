package com.nitprograms;

import java.util.Scanner;
public class MainElc {

public static void main(String[] args) {
	
	System.out.println("Enter the number :");
	
	Scanner sc = new Scanner(System.in);
	
	int num = sc.nextInt();
	int num1 = sc.nextInt();
	int num2 = sc.nextInt();
	
	// num = TwoDigitsSumBlc.getSumOfDigits(num);
	
	// num = TwoDigitsDifferenceBlc.getDiffOfDigits(num);
			
	// num = NextMultipleOfHundred.getNextMultipleOfHundred(num);
	
	num = RoundedSum.sumOfRoundedValues(num, num1, num2);
	
	System.out.println("sum is :"+ num);
	sc.close();
	
}	
}
