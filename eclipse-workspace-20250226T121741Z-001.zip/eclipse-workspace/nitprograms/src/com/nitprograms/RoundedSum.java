package com.nitprograms;

public class RoundedSum {

	public static int sumOfRoundedValues(int num, int num1, int num2) {
	
		int n = ((num%10)>5)?((num/10)+1)*10 :(num/10)*10;
		int n1 = ((num1%10)>5)?((num1/10)+1)*10 :(num1/10)*10;
		int n2 = ((num2%10)>5)?((num2/10)+1)*10 :(num2/10)*10;
		
		
		return n+n1+n2;
	}
}
