package com.nitprograms;

public class Demo {

	public static void main(String[] args) {
		int num = 27;
		
		int n = ((num%10)>5)?((num/10)+1)*10 :(num/10)*10;
		
		System.out.println(n);
	}
}
