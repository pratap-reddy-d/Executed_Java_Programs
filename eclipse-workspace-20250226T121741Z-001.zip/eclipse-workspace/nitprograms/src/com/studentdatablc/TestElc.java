package com.studentdatablc;

import java.util.Scanner;

public class TestElc {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter roll number:");
		int roll = sc.nextInt();
		
		System.out.println("Enter name:");
		sc.nextLine();
		String name = sc.nextLine();
		
		System.out.println("Enter fees:");
		double fees = sc.nextInt();
		
		StudentDataBlc.getStudentDetails(roll,name,fees);
		sc.close();
	}

}
