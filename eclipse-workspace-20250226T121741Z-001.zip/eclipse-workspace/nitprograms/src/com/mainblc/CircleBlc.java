package com.mainblc;

public class CircleBlc {

	public static String getArea(double radius) {
		
		final double pi = 3.14;
		double area = 0;
	
	   if(radius < 0 ) return "0";
	   
	   else {
		   area = pi*radius*radius;
	   }
	   
	   System.out.println(area);
	   
	   return ""+area;
	}
}
