package com.javaprgs.opps;

public class StudentElc {

	public static void main(String[] args) {
	
		StudentBlc raju = new StudentBlc();
		
		raju.properities();
		raju.marksp();
		raju.age();
	
		StudentBlc rani = new StudentBlc();
		rani.age();
		rani.marksp();
		
	}

}
