package com.javaprgs.opps;

import java.util.Scanner;

public class EmployeeElc {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Employee id:");
		int empid = sc.nextInt();
		
		System.out.println("Enter Employee name:");
		sc.nextLine();
		String empname = sc.nextLine();
		
		System.out.println("Enter Employee salary:");
		double empsalary = sc.nextDouble();
		
		EmployeeBlc empblc = new EmployeeBlc();
		
		empblc.setEmployeeData(empid, empname ,empsalary );
		empblc.getEmployeeData();
		
		sc.close();
	}

}
