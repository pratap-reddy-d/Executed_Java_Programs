package com.javaprgs.opps;

public class DogOppsElc {

	public static void main(String[] args) {
		
		DogpropertiesBlc  dog = new DogpropertiesBlc();
		
		dog.age = 21;
		dog.height = 12.2;
		dog.name = "Puppy";
		
		dog.getDogInformation();
		dog.bark();
	System.out.println("Completed!");

	}

}
