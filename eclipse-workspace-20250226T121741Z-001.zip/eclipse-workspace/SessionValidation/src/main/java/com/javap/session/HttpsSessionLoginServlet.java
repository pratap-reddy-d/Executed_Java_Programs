package com.javap.session;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;


public class HttpsSessionLoginServlet extends HttpServlet {

	protected void dopost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{ 
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		request.getRequestDispatcher("HttpSessionLink.html").include(request, response);
		
		String name = request.getParameter("Username");
		String password = request.getParameter("password");
		
		if(password.equals("admin123")) {
			out.print("Welcome,"+name);
			HttpSession session = request.getSession();
			session.setAttribute("name",name);
		}
		else {
			out.print("sorry, username or password error!");
			request.getRequestDispatcher("HttpSessionLogin.html").include(request,response);
		}
		
	}
	
}
