package com.javap.session;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class HttpSessionProfileServlet extends HttpServlet {

	protected void dopost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{ 
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		request.getRequestDispatcher("HttpSessionLink.html").include(request, response);
		
		HttpSession session = request.getSession(false);
		if(session != null) {
			String name = (String)session.getAttribute("name");
			out.print("Hello, " +name+" welcome to profile");
		}
		else {
			out.print("please login first");
			request.getRequestDispatcher("HttpSessionLogin.html").include(request, response);
		}
	
	
}}
