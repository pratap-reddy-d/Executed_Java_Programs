package com.javapg.sums;

import java.util.Scanner;

class Solution {
    public int[] twoSum(int[] nums, int target) {
        int sum =0; int[] ind = new int[2];
       
        for(int j=0;j<nums.length;j++) {
        	for(int i=j;i<nums.length-1;i++) {
        		sum = nums[j]+nums[i+1];
        		
        		if(sum == target) {
        			ind[0] = j;	
        			ind[1] = i+1;    					
        		}
       		}
        }
    	
    	return ind;
    	}
}
public class Two_sum {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] arr = {2,7,11,15};
		int target = 9;
		
		Solution s = new Solution();
	int[] sol =	s.twoSum(arr,target);
		
	for(int i=0;i<arr.length-2;i++) {
		System.out.println(sol[i]);
	}
		
	
	}
}
