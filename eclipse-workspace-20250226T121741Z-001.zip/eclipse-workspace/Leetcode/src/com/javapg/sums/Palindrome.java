package com.javapg.sums;

class Solution1 {
    public boolean isPalindrome(int x) {
        int temp = x;
        int sum =0;
        if(x>0){
             while(x!=0){
            int y = x%10; sum = sum*10;
            sum = sum+y;
            x=x/10;
        }
        }
       
        if(temp == sum)
        return true;
        else return false;
    }
}
public class Palindrome {

	public static void main(String[] args) {
		
		int number = 121;
		
		Solution1 s = new Solution1();
	System.out.println(s.isPalindrome(number));
		
	}
}
