package com.javapgr.stdu;

public class Student {

	int studentId;
	String name;
	double examFee;
	public Student(String name,int studentId, double examFee) {
		this.studentId = studentId;
		this.name = name;
		this.examFee = examFee;
	}
	
	public String displayDetails(){
		return "Student [studentId=" + studentId + ", name=" + name + ", examFee=" + examFee + "]";
	}
	
	public double payFee() {	
		return examFee;
	}
	
	@Override
	public String toString() {
		return "Student [name=" + name + ", studentId=" + studentId + ", examFee=" + examFee + "]";
	}
	
	
	
	
}
