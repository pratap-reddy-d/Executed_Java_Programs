package com.javapgr.Ticket_Management_system;

public class Main {

	public static void main(String[] args) {
		Ticket t = new Ticket("Concert", 101, 50.0);
		
		VIPTicket vp = new VIPTicket("VIP Concert", 201, 100.0, "Backstage Access");
		
		StudentTicket st = new StudentTicket("Student Event", 301, 30.0, true);
	
		System.out.println(t+"\n");
		System.out.println(vp+"\n");
		System.out.println(st);
		
	}
}
