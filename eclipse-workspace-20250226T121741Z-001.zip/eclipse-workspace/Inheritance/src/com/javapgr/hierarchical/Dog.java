package com.javapgr.hierarchical;

public class Dog extends Mammal {

	private String breed;

	public Dog(String name, boolean hasFur, String breed) {
		super(name, hasFur);
		if(breed != null)
		this.breed = breed;
		else System.err.println("Invalid input");
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}
	
	public void displayDetails() {super.displayDetails();
		System.out.println("Breed: "+getBreed());
		
	}
	
}
