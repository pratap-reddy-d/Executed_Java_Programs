package com.javapg.simplevehicle;

public class Vehicle {

	String model;
	String make;
	int year;
	public Vehicle(String make, String model, int year) {
		super();
		if(year > 0 ) {
			this.model = model;
			this.make = make;
			this.year = year;
		}
		else {
			System.err.println("Error Invalid Input");
		}
		
	}
	
	void displayDetails() {
		System.out.println("Vehicle Model"+model+"Vehicle make"+make+"Vehicle year"+year);
	}
	
	
}
