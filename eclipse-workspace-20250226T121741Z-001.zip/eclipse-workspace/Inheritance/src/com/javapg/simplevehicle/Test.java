package com.javapg.simplevehicle;

public class Test {

	public static void main(String []args) {
		
		Car car = new Car("Audi", "Q8", 2021, 7);
		car.displayDetails();
		System.out.println("\n");
		
		Bike bike = new Bike("Yamaha", "MT-07", 2020, "Sports");
		bike.displayDetails();
		
	}
}
