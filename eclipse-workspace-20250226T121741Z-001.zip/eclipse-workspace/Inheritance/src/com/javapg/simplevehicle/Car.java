package com.javapg.simplevehicle;

public class Car extends Vehicle{

	int numberOfDoors;

	public Car(String make, String model, int year, int numberOfDoors) {
		super(make, model, year);
		if(numberOfDoors > 0)
			this.numberOfDoors = numberOfDoors;
			else System.err.println("Error invalid input");
	}
	
	void displayDetails() {
		if(year !=0 && numberOfDoors != 0) {
			System.out.println("Car Details:");
			System.out.println("Make: "+super.make);
			System.out.println("Model: "+super.model);
			System.out.println("Year: "+super.year);
			System.out.println("Number of Doors: "+numberOfDoors);
		}
		
	}
}
