package com.javapg.StudentPercentage;

public class Test {

	public static void main(String[] args) {
		
		ScienceStudent scistu = new ScienceStudent("Anjali", 101, 85, 90, 80);
		scistu.displayDetails();
		
		System.out.println("\n");
		ArtsStudent artstu = new ArtsStudent("Aryan", 102, 75, 80, 85);
		artstu.displayDetails();

	}

}
