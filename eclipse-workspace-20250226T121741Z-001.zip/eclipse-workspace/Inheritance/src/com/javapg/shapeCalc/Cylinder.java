package com.javapg.shapeCalc;

public class Cylinder extends Circle {

	double height;

	public Cylinder() {
		super();
	}
	
	public Cylinder(double radius, double height) {
		super(radius);
		if(height >0 )
		this.height = height;
		else System.err.println("-1");
	}
	
	public double getVolume() {
		double volume = 3.14*super.radius*super.radius*height;
		return volume;
	}
}
