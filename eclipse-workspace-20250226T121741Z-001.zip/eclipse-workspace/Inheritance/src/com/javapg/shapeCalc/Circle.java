package com.javapg.shapeCalc;

public class Circle {

	double radius;

	public Circle() {
		super();
	}

	public Circle(double radius) {
		super();
		if(radius > 0)
		this.radius = radius;
		else System.err.println("-1");
	}
	
	public double getArea() {
		double area = 3.14*radius*radius;
		return area;
		
	}
}
