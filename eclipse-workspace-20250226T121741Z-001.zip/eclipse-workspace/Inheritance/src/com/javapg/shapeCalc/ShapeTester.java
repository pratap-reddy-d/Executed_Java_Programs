package com.javapg.shapeCalc;

public class ShapeTester {

	public static void main(String[] args) {
		
		Cylinder c = new Cylinder(5, 5);
		
		if(c.getVolume() > 0 &&c.getArea() >0 ) {
			System.out.println("Volume = "+c.getVolume());
			System.out.println("Area = "+c.getArea());
		}	
	}
}
