package com.javapg.Arrays;

import java.util.Scanner;

public class Array_Evenodd_ele {
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Array size:");
	int size = sc.nextInt();
	
	int[] arr = new int[size];
	System.out.println("Enter Array elements:");
	for(int i=0;i<arr.length;i++) {
		arr[i] = sc.nextInt();
	}
	
	System.out.println("Odd Array elements:");
	for(int i=0;i<arr.length;i++) {
		if(arr[i]%2!=0)
		System.out.println(arr[i]);
	}
	System.out.println("Even Array elements:");
	for(int i=0;i<arr.length;i++) {
		if(arr[i]%2==0)
		System.out.println(arr[i]);
	}
	
	sc.close();
}
}
