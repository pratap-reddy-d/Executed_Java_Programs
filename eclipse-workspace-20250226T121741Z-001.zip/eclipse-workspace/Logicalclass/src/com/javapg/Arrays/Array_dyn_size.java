package com.javapg.Arrays;

import java.util.Scanner;

public class Array_dyn_size {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array size:");
		int size = sc.nextInt();
		
		int[] arr = new int[size];
		System.out.println("Enter Array elements:");
		for(int i=0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Array elements:");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		sc.close();
	}
}
