package com.javapg.polymorphism;

public class Main {

	public static void main(String[] args) {
		
		FuelTank f = new FuelTank(50);
		
		Car c = new Car(f);
		c.refillFuel(30);
		c.displayFuelLevel();
		
		
		MotorCycle m = new MotorCycle(f);
		m.refillFuel(60);
		m.displayFuelLevel();

	}

}
