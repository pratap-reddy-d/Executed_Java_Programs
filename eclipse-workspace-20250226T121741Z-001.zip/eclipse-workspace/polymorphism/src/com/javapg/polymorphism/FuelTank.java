package com.javapg.polymorphism;

public class FuelTank {

	private double fuelLevel;
	private double maxCapacity;
	
	public FuelTank(double maxCapacity) {
		super();
		this.maxCapacity = maxCapacity;
		this.fuelLevel = 0;
	}
	
	public double getFuelLevel() {
		return fuelLevel;
	}
	
	public void refillFuel(double amount) {
	
		if(fuelLevel+amount < maxCapacity) {
			fuelLevel+=amount; 
			System.out.println("Fuel refilled. Current fuel level: " + fuelLevel + " liters");
		}
		else {
			System.out.println("Cannot refill. Tank capacity exceeded.");
		}
	
	}
}
