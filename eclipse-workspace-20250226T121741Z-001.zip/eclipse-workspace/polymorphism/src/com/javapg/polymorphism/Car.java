package com.javapg.polymorphism;

public class Car extends Vehicle {

	public Car(FuelTank fuelTank) {
		super(fuelTank);
		
	}

}
