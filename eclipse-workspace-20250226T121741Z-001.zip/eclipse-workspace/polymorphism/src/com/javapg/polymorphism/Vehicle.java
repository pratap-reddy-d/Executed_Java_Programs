package com.javapg.polymorphism;

public class Vehicle {

	private FuelTank fuelTank;

	public Vehicle(FuelTank fuelTank) {
		super();
		this.fuelTank = fuelTank;
	}
	
	void displayFuelLevel(){
		System.out.println("Current fuel level: " + fuelTank.getFuelLevel() + " liters");
	}
	public void refillFuel(double amount){
		fuelTank.refillFuel(amount);
		}
}
