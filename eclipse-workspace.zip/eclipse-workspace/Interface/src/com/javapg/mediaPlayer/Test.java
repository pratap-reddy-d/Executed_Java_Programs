package com.javapg.mediaPlayer;

public class Test {
	
	public static void main(String[] args) {
		
		VideoPlayer vp = new VideoPlayer("");
		vp.play();
		vp.pause();
		vp.stop();		
		
		MusicPlayer mp = new MusicPlayer("");
		mp.play();
		mp.pause();
		mp.stop();
		
	}
	
}
