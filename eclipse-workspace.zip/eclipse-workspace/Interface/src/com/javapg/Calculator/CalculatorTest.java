package com.javapg.Calculator;

import java.util.Scanner;

public class CalculatorTest {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the size");
		
		int size = in.nextInt();
		System.out.println("Enter the numbers");
		int[] n1 = new int[size] ;
		
		for(int i=0;i<n1.length;i++) {
			n1[i] = in.nextInt();
		}
		
		Simplecalculator sc = new Simplecalculator();
		
		sc.calculateSum(n1);

		in.close();
	}

}
