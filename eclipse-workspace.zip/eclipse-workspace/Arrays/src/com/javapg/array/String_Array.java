package com.javapg.array;

public class String_Array {
 public static void main(String[] args) {
	
	 String_Array[] str = new String_Array[5]; 
	 
	 for(int i=0;i<str.length;i++) { // intital stores null for string and for array stores 0
		 System.out.println(str[i]);
	 }
	 
	 String[] arr = new String[3]; 
	 for(String i : arr)
	 System.out.println(i);
	 
}
}
