package com.javapg.Arraycopy;

import java.util.Arrays;

public class IndexRangeCopyArray {

	public static void indexCopy(int[] arr, int start,int end) {
	
		int length = end-start;
		
		if(length < 0) {
			throw new IllegalArgumentException("From = " + start+" > To ="+end);
		}
		
		int[] arr1 = new int[length];
		
		System.out.println(arr1.length);
				
		for(int i=start,j=0;i<end || j<arr1.length-1;i++,j++) {
			arr1[j] = arr[i];
		}
		
		System.out.println(Arrays.toString(arr1));
		
	}
	
	public static void main(String[] args) {
		
		int[] arr = {10, 20, 30, 40, 50, 60};
		indexCopy(arr,2,4);
	}
}
