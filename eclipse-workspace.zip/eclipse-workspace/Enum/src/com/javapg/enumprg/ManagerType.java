package com.javapg.enumprg;

public enum ManagerType {

	HR ,SALES;
}
