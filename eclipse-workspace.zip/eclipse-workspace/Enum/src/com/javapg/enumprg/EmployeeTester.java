package com.javapg.enumprg;

public class EmployeeTester {

	public static void main(String[] args) {
		
		
		Manager m = new Manager("Pratap",101,50000,ManagerType.HR);
	//	m.setSalary(90000);
		System.out.println("salary "+m.getSalary());
		
		
	}

}
