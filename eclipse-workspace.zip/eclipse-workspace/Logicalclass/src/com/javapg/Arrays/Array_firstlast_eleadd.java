package com.javapg.Arrays;

import java.util.Scanner;

public class Array_firstlast_eleadd {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array size:");
		int size = sc.nextInt();
		
		int[] arr = new int[size];
		System.out.println("Enter Array elements:");
		
		for(int i=0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Addition of 1st and last Array elements:"+(arr[0]+arr[arr.length-1]));
		
		
		
		sc.close();
	}
}
