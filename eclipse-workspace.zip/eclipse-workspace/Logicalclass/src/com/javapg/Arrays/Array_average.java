package com.javapg.Arrays;

import java.util.Scanner;

public class Array_average {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array size:");
		int size = sc.nextInt();
		
		int[] arr = new int[size];
		
		System.out.println("Enter Array elements:");
		for(int i=0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		
		int sum =0;
		
		for(int i=0;i<arr.length;i++) {
			sum = sum+arr[i];
			
		}
		System.out.println("Average of Array elements: "+sum/arr.length);
		
		sc.close();

	}

}
