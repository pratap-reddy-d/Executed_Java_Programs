package com.javapg.Arrays;

public class Array_mid_element {

	public static void main(String[] args) {
		
		int[] arr = {1,2,3,4,5}; // {1,2,3,4,5,6};
		
		
			if(arr.length%2!=0) {
				System.out.println(arr[arr.length/2]);
			}
			else {
				System.out.println(arr[(arr.length/2)-1]+" "+arr[arr.length/2]);
			}
		}

	}