package com.javapg.Arrays;

public class Array_indexvalue {

	public static void main(String[] args) {
		
		int[] arr = {100,200,300,400,500};
		
		System.out.println(arr[3]);
	}
}
