package com.javapg.newtask;

public class CabCustomerServiceTester {

	public static void main(String[] args) {
		
		CabCustomer c1 = new CabCustomer(1,"jhon","Smerpet","hf",8,"79463");
		CabCustomerService c2 = new CabCustomerService();
		c2.addCabCustomer(c1);
		c2.calculateBill(c1);
	}
}
