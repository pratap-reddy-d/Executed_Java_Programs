package com.javapg.newtask;

import java.util.ArrayList;

public class CabCustomerService {

	private ArrayList<CabCustomer> CustomerList = new ArrayList<>();
	
	public void addCabCustomer(CabCustomer a) {
		CustomerList.add(a); 
	};
	
	public boolean isFirstCustomer(CabCustomer c) {
		int customerCount =0;
		for( CabCustomer cc : CustomerList) {
			
			if(cc.getPhone().equals(c.getPhone())){
				customerCount++;
			}
	}
		return customerCount==1;
		}
	
	public double calculateBill(CabCustomer c) {
		if(isFirstCustomer(c))
		return 0;
		else if(c.getDistance() <= 4)
			return 80;
		else 
			return 80+(6*c.getDistance()-4);
			
		}
		
		public String printBill(CabCustomer c) {
			
			return ""+c.getCustomerName()+"Please pay your bill of Rs."+calculateBill(c);
		}
		
		
	}

