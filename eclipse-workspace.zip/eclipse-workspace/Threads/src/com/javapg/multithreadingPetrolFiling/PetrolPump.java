package com.javapg.multithreadingPetrolFiling;

public class PetrolPump {

	static synchronized void refillCar(String carName) {
		System.out.println(carName+" Started filling.");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(carName+" filing completed");
	}
	
	
}
