package com.javapg.bakeryMultithread;

public class BakeryExample {

	public static void main(String[] args) {
		
		Bakery b = new Bakery();
		
		Baker baker1 = new Baker(b);
		
		Thread tb = new Thread(baker1);
		tb.start();
		
		Customer c = new Customer(b, "cuto 1");
		Customer c1 = new Customer(b, "cuto 2");
		Customer c2 = new Customer(b, "cuto 3");
		Customer c3 = new Customer(b, "cuto 4");
		
		Thread ct1 = new Thread(c);
		Thread ct2 = new Thread(c1);
		Thread ct3 = new Thread(c2);
		Thread ct4 = new Thread(c3);

		
		try {
			tb.join();
			ct1.join();
			ct2.join();
			ct3.join();
			ct4.join();			
		}
		catch(InterruptedException e) {
			 Thread.currentThread().interrupt();
		}
		
		System.out.println("Bakery operation has finished for the day.");
		
	}
}
