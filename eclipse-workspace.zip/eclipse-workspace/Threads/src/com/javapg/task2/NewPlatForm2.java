package com.javapg.task2;

public class NewPlatForm2 {

	public static void main(String[] args) {
		
		{
			new Thread() {
				public void run() {
					for(int i=1;i<=(3^5);) {
						System.out.println("Enjoy your platform"+i);
						break;
					}
				}
			}.start();
			
			new Thread() {
				public void run() {
					for(int i=1;i<=(3^5);) {
						if(i==(3^4))
						System.out.println("Experience this new platform"+i);
						break;
					}
				}
			}.start();
		}
		
		
	}
}
