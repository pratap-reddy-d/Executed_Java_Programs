package com.javapg.task2;

class Test extends Thread{
	public void run() {
		for(int i=0;i<=3;i++) {
			System.out.println("Hello Welcome here.."+i);
		}
	}
}

public class NewPlatForm1 {

	public static void main(String[] args) {
		
		Test t = new Test();
		t.start();
		Test t1 = new Test();
		t1.start();
	}
}
