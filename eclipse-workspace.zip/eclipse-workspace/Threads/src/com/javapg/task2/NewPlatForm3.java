package com.javapg.task2;

public class NewPlatForm3 {

	public static void main(String[] args) {
		
		Runnable r = new Runnable()
		{
			public void run() {
				System.out.println("How about new platform?");
			}
		};
		
		Runnable r1 = new Runnable() {
			public void run() {
				System.out.println("Are you enjoying new platform?");
			}
		};
		
		Thread t1 = new Thread(r);
		
		Thread t2 = new Thread(r1);
		t1.start();
		t2.start();
	}
}
