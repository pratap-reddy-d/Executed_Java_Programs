package com.javapg.threadtask;

class First implements Runnable{
	@Override
	public void run() {
		for(int a=0;a<10;a++) {
			System.out.println("First Thread"+a);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				System.out.println("NIT or first thread failed");
			}
		}
	}
}

class Second implements Runnable{
	 @Override
	 public void run() {
		 for(int a=0;a<10;a++) {
			 System.out.println("Second Thread"+a);
			 try {
				 Thread.sleep(500);
			 }
			 catch(InterruptedException e) {
				 System.out.println("Second thread failed");
			 }
		 }
			 }
}

public class Thread_runnable {
public static void main(String[] args) {
	
	Runnable first = new First();
	Runnable second = new Second();
	
	System.out.println(Thread.currentThread().getName());
	Thread n1 = new Thread(first);
	Thread n2 = new Thread(second);
	n1.start();
	n2.start();
}
}
