package com.javapg.threadtask;


class NIT1 extends Thread{
	
	@Override
	public void run() {
		System.out.println("1st thread");
	}
}

class NIT2 extends Thread{
	@Override
	public void run() {
		System.out.println("2nd thread");
	}
}

public class NIT extends Thread{
public static void main(String[] args) {

	NIT1 n1 = new NIT1();
	
	NIT2 n2 = new NIT2();
	
	Thread n = new Thread(n1,"demo");
	n.start();
	
	System.out.println(n.getPriority());
	System.out.println(n.isAlive());
	
	System.out.println(n2.isAlive());
	
	n2.start();
	
	System.out.println(n2.getPriority());
	

}
	
}
