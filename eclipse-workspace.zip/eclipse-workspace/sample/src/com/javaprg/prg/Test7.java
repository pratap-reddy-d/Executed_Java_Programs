package com.javaprg.prg;

class Vehicle{
	private double price = 1234;
	String type = "car";
	String mode ;
	Vehicle(String mode){
		System.out.println(type);
		this.mode = mode;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}
class Car extends Vehicle{
	double price = 45676;
	String model = "new";
	Car(){
		super("petrol");
		System.out.println(mode);
		System.out.println(super.getPrice());
	}
	
}

class Bike extends Vehicle{
	double price = 890;
	String model = "2 wheel";
	Bike(){
		super("ev");
		System.out.println(model);
		System.out.println(this.price);
	}
}
class Test7{
	public static void main(String[] args) {
		Car c = new Car();
		System.out.println(c.price);
		new Bike();
	}
}