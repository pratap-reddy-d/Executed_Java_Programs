package com.nareshitjavaprgs;

import java.util.Scanner;

public class CalculateSimpleInterest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Principle Amount: ");
		float principleAmt = sc.nextFloat();
		
		System.out.println("Enter Rate of Interest: ");
		float rate = sc.nextFloat();
		//rate = rate/100;
		
		System.out.println("Enter Time in Years: ");
		float time = sc.nextFloat();
		
		float total = (principleAmt*rate*time)/100;
		

		System.out.println("Simple Interest :"+total);
		System.out.println("Total Amount: "+(total+principleAmt));
		
		sc.close();
	}

}
