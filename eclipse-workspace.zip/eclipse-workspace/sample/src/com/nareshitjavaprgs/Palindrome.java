package com.nareshitjavaprgs;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int number = sc.nextInt();
	//	int number1 = number;
		int rev = 0;
		
		for(int i = number;i!=0;i=i/10) {
		 int last = i%10;
		 rev = rev*10+last;
		}
		
		System.out.println(number==rev?"It is a Palindrome":"Not a Palindrome");
		sc.close();
	}
}
