package com.nareshitjavaprgs;

public class EvenNumbers {

	public static void main(String[] args) {
		
		int count = 0;
		
		System.out.println("Even Numbers between 1-100: ");
		
		for(int i = 0; i<=100;i++) {
			
			if(i%2 == 0 ) {
				count++;
				System.out.println(i);
			}
		}
		System.out.println("Count is :"+count);
		

	}

}
