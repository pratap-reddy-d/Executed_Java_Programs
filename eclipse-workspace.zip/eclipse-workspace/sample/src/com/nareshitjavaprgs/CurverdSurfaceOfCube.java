package com.nareshitjavaprgs;

public class CurverdSurfaceOfCube {

	public static void main(String[] args) {
		
		int side = Integer.parseInt(args[0]);		
		double value = 6*side*side;

		System.out.println("Curverd Surface Of Cube is "+ value);
	}

}
