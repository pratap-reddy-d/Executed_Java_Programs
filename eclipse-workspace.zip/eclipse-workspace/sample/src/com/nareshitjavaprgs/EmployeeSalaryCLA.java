package com.nareshitjavaprgs;

import java.util.Scanner;

public class EmployeeSalaryCLA {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int basicSalary = Integer.parseInt(args[0]);
	    int hra = 15;
	    int conveyanceallo = 15;
	    int entertinment = 10;
	    
	    float hraSal = basicSalary*hra/100;
	    float conveancealloSal = basicSalary*conveyanceallo/100;
	    float entertinmentSal =  basicSalary*entertinment/100;
	    
	    System.out.println("The total salary is: "+(basicSalary+hraSal+conveancealloSal+entertinmentSal));
	
	    sc.close();
	}

}
