package com.nareshitjavaprgs;

public class SumOfTwoNumbersCLA {

	public static void main(String[] args) {
		
		
		int number = Integer.parseInt(args[0]);
		int number1 = 0;
		
		while(number!=0) {
			
			number1 += number%10;
			number=number/10;;
		}
		
		for(int i = number; i!=0;i=i/10) {
			number1 += i%10; 
		}
		
		System.out.println("Sum is : "+number1);

	}

}
