package com.nareshitjavaprgs;

public class ParseDoubleFloatAdd {

	public static void main(String[] args) {
		
		double value = Double.parseDouble(args[0]);
		double value1 = Double.parseDouble(args[1]);
		
		float f1 =(float) value;
		float f2 =(float) value1;
		
		System.out.println("Multiplication is: "+(f1*f2));
	}
}
