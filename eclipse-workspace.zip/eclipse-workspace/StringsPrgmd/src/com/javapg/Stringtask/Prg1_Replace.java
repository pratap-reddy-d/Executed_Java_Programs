package com.javapg.Stringtask;
/*
 * Write a Java program to replace all occurrences of a
specified value in a string using the replace() method.

String s = "java is PI, java is OOPL, java is MT";
String word = "Python";
s = s.replace("java", word);
System.out.println(s);
 */

public class Prg1_Replace {

	public static void main(String[] args) {
		String s = "java is PI, java is OOPL, java is MT";
		
		String word = "python";
		
		s=s.replace("java", word);
		
		System.out.println(s);
	}
}
