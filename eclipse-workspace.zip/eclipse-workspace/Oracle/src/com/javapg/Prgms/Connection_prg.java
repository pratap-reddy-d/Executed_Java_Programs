package com.javapg.Prgms;

import java.util.Scanner;

public class Connection_prg {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		try {
			Class.forName("Oracle:jdbc:driver.OracleDriver");
			
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
