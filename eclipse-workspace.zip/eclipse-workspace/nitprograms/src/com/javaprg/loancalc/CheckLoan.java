package com.javaprg.loancalc;

import java.util.Scanner;

public class CheckLoan {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Principal amt:");
		 double principal = sc.nextDouble();
		 System.out.println("Enter Intrestrate:");
		 double intrestRate = sc.nextDouble();
		 System.out.println("Enter duration monthds:");
		 int durationMonths = sc.nextInt();
		 
		 Loan ln = new Loan(principal, intrestRate, durationMonths);
		 
		 
		 System.out.println(ln);
		 sc.close();
	}

}
