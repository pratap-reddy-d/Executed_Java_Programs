package com.javaprg.loancalc;

public class Employee {

	public int employeeNumber;
	public String employeeName;
	public double employeeSalary;

	public Employee(int employeeNumber, String employeeName, double employeeSalary) {
		super();
		if(employeeNumber <= 0) {
			this.employeeNumber = 0;
			System.err.println("id must be always positive integer");
		}
		else {
			this.employeeNumber = employeeNumber;
		}
		
		
		if(employeeName == null) {
			this.employeeName = "";
			System.err.println("name must initialize with any default name");
		}
		else {
			this.employeeName = employeeName;
		}
		
		if(employeeSalary <= 0) {
			this.employeeSalary = 0.0;
			System.err.println("Fee cannot be negative");
		}
		else {
			this.employeeSalary = employeeSalary;
		}
		
	}

	public double getEmployeeSalary() {
		if(employeeSalary >= 60000) {
			System.out.println("Employee is a Developer");
		}
		else if(employeeSalary >= 40000 && employeeSalary < 60000) {
			System.out.println("Employee is a Designer"
					+ "");
		}
		else if(employeeSalary < 40000) {
			System.out.println("Employee is a Tester");
		}
		return employeeSalary;
	}

	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + "]";
	}
	
	
	
	
}
