package com.javaprg.loancalc;

public class Loan {

	private double principal;
	private double intrestRate;
	private int durationMonths;
	double total;
	
	public Loan(double principal, double intrestRate, int durationMonths) {
		
		this.principal = principal;
		this.intrestRate = intrestRate;
		this.durationMonths = durationMonths;
		calculateMonthlyPayment();
	}
	
	public double calculateMonthlyPayment() {
		
		total = (getPrincipal()*getDurationMonths()*getInterestRate())/(12*100);
		return total;
	}
	
	public double getPrincipal() {
		
		return principal;
		
	}
	
	public double getInterestRate() {
		return intrestRate;
	}
	public int getDurationMonths() {
		return durationMonths;
	}

	@Override
	public String toString() {
		return "Loan [principal=" + principal + ", intrestRate=" + intrestRate + ", durationMonths=" + durationMonths
				+ ", total=" + (total+principal) + "]";
	}
	
	
}
