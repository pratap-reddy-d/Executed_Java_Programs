package com.javaprg.abstraction;

import java.util.Scanner;

public class EmpoyeeElc {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
	String firstName = sc.nextLine();
	String lastName = sc.nextLine();
	int employeeId = sc.nextInt();
	double salary = sc.nextDouble();
	int noOfProject = sc.nextInt();
		
		EmployeeBlc emp = new EmployeeBlc(firstName,lastName,employeeId,salary,noOfProject);
		emp.calculateSalary();
		
		sc.close();
	}

}
