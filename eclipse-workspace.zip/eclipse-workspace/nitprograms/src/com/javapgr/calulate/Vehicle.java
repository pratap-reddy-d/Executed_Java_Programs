package com.javapgr.calulate;

public class Vehicle {
	
	private double totalDistance;
	private double totalFuelConsumed;
	public Vehicle(double totalDistance, double totalFuelConsumed) {
		super();
		this.totalDistance = totalDistance;
		this.totalFuelConsumed = totalFuelConsumed;
	}
	
	public double calculateFuelEfficiency1(double km, double ltr) {
		
		return km/ltr;
		
	}
	
    public double calculateFuelEfficiency(double miles,double gallon) {
		return miles/gallon;
	}
}
