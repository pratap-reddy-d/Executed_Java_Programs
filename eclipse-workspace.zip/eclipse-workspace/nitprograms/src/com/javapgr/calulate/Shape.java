package com.javapgr.calulate;

public class Shape {
	
public double calculateVolume(double radius) {
		
		double side = 4/3*3.14*radius*radius;
		return side;
	}
	
	public double calculateVolume(double radius, double height) {
		
		double side = 3.14*radius*radius*height;
		return side;
	}
   public double calculateVolume1(double sideLength) {
		
		double side = sideLength*sideLength*sideLength;
		return side;
	}
}
