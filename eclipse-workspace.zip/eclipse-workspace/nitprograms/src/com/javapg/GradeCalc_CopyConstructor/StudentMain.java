package com.javapg.GradeCalc_CopyConstructor;

public class StudentMain {

	public static void main(String[] args) {
		
		
		Student s1 = new Student("Scot", 1201, "cse", 1200000,68);
	//	s1.calculateGrade();
		System.out.println(s1);
		
		Student s2 = new Student(s1);
		//s2.calculateGrade();
		System.out.println(s2);
		
		
	}

}
