package com.javapg.employee;

public class InventoryItem {

	private String itemName;
	private double pricePerUnit;
	private int quantityInStock;
	private double tamt = 0;
	
	public InventoryItem(String itemName, double pricePerUnit, int quantityInStock) {
		super();
		
		if(itemName != null && itemName != "") {
			this.itemName = itemName;
		}
		else System.err.println("Invalid item name");
		
		if(pricePerUnit > 0)
		this.pricePerUnit = pricePerUnit;
		else System.err.println("Invalid price");
		
		if(quantityInStock > 0)
		this.quantityInStock = quantityInStock;
		else System.err.println("Invalid quantity");
		
		calculateTotalValue();
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getPricePerUnit() {
		return pricePerUnit;
	}

	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	public int getQuantityInStock() {
		return quantityInStock;
	}

	public void setQuantityInStock(int quantityInStock) {
		this.quantityInStock = quantityInStock;
	}
	
	public double calculateTotalValue() {
		
		this.tamt = this.quantityInStock * this.pricePerUnit;
		return tamt;
	}

	@Override
	public String toString() {
		String k ="";
		if(itemName!=null && pricePerUnit !=0 && quantityInStock != 0 && tamt != 0)
		k =  "Total value of "+ itemName + "in Stock :"+tamt;
		return  k;
	}
	
	
	
}
