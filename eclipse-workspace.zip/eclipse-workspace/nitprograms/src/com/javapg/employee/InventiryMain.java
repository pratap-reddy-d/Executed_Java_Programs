package com.javapg.employee;

public class InventiryMain {

	public static void main(String[] args) {
		
		InventoryItem it = new InventoryItem("Apple", 5.0, -15);

		System.out.println(it.toString());
	}

}
