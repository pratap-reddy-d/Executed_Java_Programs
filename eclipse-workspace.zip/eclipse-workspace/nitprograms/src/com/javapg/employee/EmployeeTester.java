package com.javapg.employee;

public class EmployeeTester {

	public static void main(String[] args) {
		
		Employee emp = new Employee("shaktiman", 30, "sales", 50000, "good");
	//	Employee emp1 = new Employee();
	//	Employee emp2 = new Employee();

		System.out.println(emp);
		
	}

}
