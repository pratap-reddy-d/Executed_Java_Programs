package com.evenorodd;

public class EvenOrOddBlc {

	public static boolean isEven(int n) {
		
		
		if((n/2)==1) return false;
		else return true;
	}
}
