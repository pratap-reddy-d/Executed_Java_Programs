package com.spynumber;

public class CalculateBlc {

	public static void checkSpyNum(int num) {
		
		int sum = 0;
		int mul = 1;
		
		for(int i = num; i!=0;i/=10) {
			int temp = i%10;
			sum = sum +temp;
			mul = mul * temp;
		}
		
		System.out.println(sum==mul?"Spy Number":"Not a Spy Number");
	}
}
