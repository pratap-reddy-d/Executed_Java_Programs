package com.mainblc;

import java.util.Scanner;
public class TestElc {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius of Circle: ");
		double n = sc.nextInt();
		
		String a = CircleBlc.getArea(n);
		System.out.printf(a);
		sc.close();
	}

}
