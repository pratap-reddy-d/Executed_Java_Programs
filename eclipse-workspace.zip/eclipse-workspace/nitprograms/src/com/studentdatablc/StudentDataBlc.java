package com.studentdatablc;

public class StudentDataBlc {

	public static String getStudentDetails(int roll, String name, double fees) {
		
		System.out.print("Roll is:"+roll+", Name is:"+name+", Fees is:"+fees);
		return ""+0;
	}
}
