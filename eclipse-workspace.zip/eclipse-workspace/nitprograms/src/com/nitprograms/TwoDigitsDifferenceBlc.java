package com.nitprograms;

public class TwoDigitsDifferenceBlc {

	public static int getDiffOfDigits(int num) {
		
		int diff = 0;
		
		
		    int  i =  num; 
		    
			int tempLast = i%10;
			
			i/=10;
			
			int tempFirst = i%10;
			
			diff = tempFirst - tempLast;
			 
		return diff;
	}
}
