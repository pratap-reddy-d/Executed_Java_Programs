package com.javaprgs.opps;

public class EmployeeBlc {

	
	int id;
	String name;
	double salary;
	
	public void setEmployeeData(int empid, String empname, double empsalary ) {
		
		id = empid;
		name = empname;
		salary = empsalary;
	}
	
    public void getEmployeeData() {
	
    	System.out.println("Employee id is: "+id);
    	System.out.println("Employee name is: "+name);
    	System.out.println("Employee salary is: "+salary);
	}
}
