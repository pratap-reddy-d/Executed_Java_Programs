package com.javaprgs.opps;

public class FanElc {

	public static void main(String[] args) {
		
		FanBlc fb = new FanBlc();
		
		fb.coil = "Dark";
		fb.name = "Havells";
		fb.wings = 5;
		
		fb.switchOn();
		fb.switchOff();
		
	}

}
