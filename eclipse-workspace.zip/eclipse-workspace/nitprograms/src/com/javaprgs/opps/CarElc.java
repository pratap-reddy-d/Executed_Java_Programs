package com.javaprgs.opps;

public class CarElc {

	public static void main(String[] args) {
		
		CarBlc c = new CarBlc();
		
		c.color = "White";
		c.company = "fortuner";
		c.speed = 300;
		
		c.carcompany();
		c.carspeed();
		c.carcolor();
		
	}

}
