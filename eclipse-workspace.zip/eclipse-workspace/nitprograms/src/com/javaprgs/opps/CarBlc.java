package com.javaprgs.opps;

public class CarBlc {

	String company;
	String color;
	int speed;
	
	public void carspeed() {
		System.out.println("Car speed "+speed);
	}
	
	public void carcolor() {
		System.out.println("car color "+color);
	}
	
	public void carcompany() {
		System.out.println("car company "+company);
	}
	
	
}

