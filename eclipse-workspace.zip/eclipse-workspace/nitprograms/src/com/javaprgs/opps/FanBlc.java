package com.javaprgs.opps;

public class FanBlc {

	int wings;
	String coil;
	String name;
	
	public void switchOn() {
		System.out.println("coil "+coil+"\nwings "+wings+"\nname"+name);
		System.out.println("Fan is on");
	}
	
	public void switchOff() {
		System.out.println("Is off");
		}
}
