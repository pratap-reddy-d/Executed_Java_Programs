package com.javaprgs.opps;

import java.util.Scanner;

public class ProductElc {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Product name:");
		String name = sc.next();
		
		System.out.println("Enter Product id:");
		int id = sc.nextInt();
		
		System.out.println("Enter Product price:");
		double price = sc.nextDouble();

		ProductBlc pblc = new ProductBlc();
		
		pblc.setProductData(id, name, price);
		pblc.getProductData();
		
		sc.close();
	}

}
