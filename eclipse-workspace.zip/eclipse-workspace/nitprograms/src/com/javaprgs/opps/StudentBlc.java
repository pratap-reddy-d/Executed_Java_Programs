package com.javaprgs.opps;

public class StudentBlc {

	int marks;
	int age;
	char grade;
	
	public void properities() {
		marks = 23;
		age = 21;
		grade = 'F';
	}
	
	public void marksp() {
		System.out.println("Marks :"+marks);
	}
	
	public void age() {
		System.out.println("Age :"+age +"\ngrade :"+grade);
	}
	
}
