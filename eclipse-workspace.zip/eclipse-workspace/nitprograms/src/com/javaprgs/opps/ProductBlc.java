package com.javaprgs.opps;

public class ProductBlc {
	
	int id;
	String name;
	double price;

	public void setProductData(int productId, String productName, double productprice)
	{
		
		name = productName;
		id = productId;
		price = productprice;
		
	}
	
	public void getProductData() {
		System.out.println("Product Name is :"+name+"\nProduct Price is :"+price+"\nProduct id is :"+id);
	}
}
