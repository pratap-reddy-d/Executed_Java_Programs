package com.javaprgs.opps;

public class DogpropertiesBlc {

	int age;
	double height;
	String name;
	
	public void getDogInformation() {
		System.out.println("Name is: "+name+" \n height is: "+height+"\n age is: "+age);
	}
	
	public void bark() {
		System.out.println("When intrusers enterd only");
	}
}
