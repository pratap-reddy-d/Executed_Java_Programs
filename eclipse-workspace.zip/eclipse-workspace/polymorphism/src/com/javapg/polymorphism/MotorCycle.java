package com.javapg.polymorphism;

public class MotorCycle extends Vehicle{

	public MotorCycle(FuelTank fuelTank) {
		super(fuelTank);
		
	}

}
