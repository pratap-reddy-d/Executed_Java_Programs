package com.javapg.mulithreadingsetA;

public class HistoryStudent extends Student{

	private int historyMarks;
	private int civicsMarks;
	
	private int percentage;
	private boolean percentageCalculated = false;
	
	int getPercentage() {
		
		percentage = (historyMarks+civicsMarks/300)*100;
		return percentage;
		
	}
	void isPrompted(){
		
	}
	@Override
	boolean getTotalNoOfStudents() {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
