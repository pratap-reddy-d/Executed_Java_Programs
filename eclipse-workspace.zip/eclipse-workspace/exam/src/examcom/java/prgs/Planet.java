package examcom.java.prgs;

public class Planet {
	
	String planetName;
	double mass;
	double radius;
		
  void setPlanetDetails(String planetName, double mass,	double radius) {
	  this.planetName = planetName;
	  this.mass = mass;
	  this.radius = radius;
  }

  String getPlanetDetails() {
	  
	return planetName+"\n"+mass+" kg\n"+radius+" km";
	  
  }

}
