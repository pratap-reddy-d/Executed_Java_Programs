package examtoday.com;

public class ApplianceElc {

	public static void main(String[] args) {
		
		ApplianceBlc app = new ApplianceBlc("Fridge",27); 
		ApplianceBlc app1 = new ApplianceBlc("Cooler",27,"Electronic"); 

		app1.displayInfo();
		
	}

}
