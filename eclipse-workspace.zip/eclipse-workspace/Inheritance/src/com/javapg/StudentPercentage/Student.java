package com.javapg.StudentPercentage;

public class Student {

	protected String name;
	protected int rollNumber;
	public Student(String name, int rollNumber) {
		super();
		if(rollNumber >0) {
			this.name = name;
			this.rollNumber = rollNumber;
		}
		else System.err.println("Invalid input");
		
	}
	
	public void displayDetails() {
		
	}
	public double calculatePercentage() {
		
		return 0;
	}
	
}
