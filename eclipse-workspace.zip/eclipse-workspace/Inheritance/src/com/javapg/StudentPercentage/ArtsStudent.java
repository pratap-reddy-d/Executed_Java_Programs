package com.javapg.StudentPercentage;

public class ArtsStudent extends Student{

	private int historyMarks;
	private int geographyMarks;
	private int englishMarks;
	public ArtsStudent(String name, int rollNumber, int historyMarks, int geographyMarks, int englishMarks) {
		super(name, rollNumber);
		if(historyMarks>0 && geographyMarks >0 && englishMarks>0) {
			this.historyMarks = historyMarks;
			this.geographyMarks = geographyMarks;
			this.englishMarks = englishMarks;
		}
		else System.err.println("invalid input");
	}
	
	public void displayDetails() {
		System.out.println("Science Student Details:");
		System.out.println("Name: "+super.name);
		System.out.println("Roll Number: "+super.rollNumber);
		System.out.println("Physics Marks: "+historyMarks);
		System.out.println("Chemistry Marks: "+geographyMarks);
		System.out.println("Maths Marks: "+englishMarks);
		System.out.println("Percentage: "+calculatePercentage()+"%");
	}
	public double calculatePercentage() {
		double total = (englishMarks+geographyMarks+historyMarks)/3;
		return total;
	}
}
