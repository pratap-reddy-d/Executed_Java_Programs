package com.javapg.StudentPercentage;

public class ScienceStudent extends Student {

	private int physicsMarks;
	private int chemistryMarks;
	private int mathMarks;
	public ScienceStudent(String name, int rollNumber, int physicsMarks, int chemistryMarks, int mathMarks) {
		super(name, rollNumber);
		if(physicsMarks > 0 &&  chemistryMarks > 0 && mathMarks > 0) {
			this.physicsMarks = physicsMarks;
			this.chemistryMarks = chemistryMarks;
			this.mathMarks = mathMarks;
		}
		else System.err.println("Invalid input");
	}
	
	public void displayDetails() {
		System.out.println("Science Student Details:");
		System.out.println("Name: "+super.name);
		System.out.println("Roll Number: "+super.rollNumber);
		System.out.println("Physics Marks: "+physicsMarks);
		System.out.println("Chemistry Marks: "+chemistryMarks);
		System.out.println("Maths Marks: "+mathMarks);
		System.out.println("Percentage: "+calculatePercentage()+"%");
		
	}
	public double calculatePercentage() {
		
		double total = (physicsMarks+chemistryMarks+mathMarks)/3;
		return total;
	}
	
}
