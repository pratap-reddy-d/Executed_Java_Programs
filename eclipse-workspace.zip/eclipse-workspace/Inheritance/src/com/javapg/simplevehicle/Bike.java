package com.javapg.simplevehicle;

public class Bike extends Vehicle{

	String type;

	public Bike(String make, String model, int year, String type) {
		super(make, model, year);
		this.type = type;
	}
	
	void displayDetails() {
		if(year != 0) {
			System.out.println("Bike Details:");
			System.out.println("Make: "+super.make);
			System.out.println("Model: "+super.model);
			System.out.println("Year: "+super.year);
			System.out.println("Type: "+type);
		}		
	}
}
