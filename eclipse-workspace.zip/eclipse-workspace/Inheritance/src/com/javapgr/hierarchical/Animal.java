package com.javapgr.hierarchical;

public class Animal {
  private String name;

public Animal(String name) {
	super();
	if(name != null)
	this.name = name;
	else System.err.println("Invalid input");
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
  
  public void animalDetails() {
	  System.out.println("Animal Name: "+getName());
  }
}
