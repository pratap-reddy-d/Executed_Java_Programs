package com.javapgr.hierarchical;

public class Main {

	public static void main(String[] args) {
		Dog d = new Dog("Buddy",false,"Golden Retriever");
		System.out.println("Dog Details:");
		d.displayDetails();
		
	}

}
