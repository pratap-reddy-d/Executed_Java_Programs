package com.javapgr.stdu;

public class DayScholar extends Student {

	double transportFee;

	public DayScholar(int studentId, String name, double examFee, double transportFee) {
		super(name,studentId, examFee);
		this.transportFee = transportFee;
	}

	
	public String displayDetails() {
		return "DayScholar [transportFee=" + transportFee + ", name=" + name + ", studentId=" + studentId + ", examFee="
				+ examFee + "]";
	}
	
public String payFee(double tamt) {
		
		double t =  transportFee+examFee;
		String n = null;
		if(tamt == t) {
			n = "All Fees are clear";
		}
		else if(tamt < t) {
			t = t-tamt;
			n = "Remaining amount to pay is: "+t;
		}
		else {
			t = t-tamt ;
			n = "Extra Reamining balance is:"+t;
		}
		return n;
	}

		
}
