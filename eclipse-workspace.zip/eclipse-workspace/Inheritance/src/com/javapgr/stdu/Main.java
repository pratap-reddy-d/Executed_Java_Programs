package com.javapgr.stdu;

public class Main {

	public static void main(String[] args) {
		

		double tamt = 3000;
		Student st = new Student("John Smith", 1, 25000.0);
		System.out.println(st);
		System.out.println("\n");
		
		DayScholar ds = new DayScholar(2, "Brain", 25000, 5000);
		System.out.println(ds.displayDetails());
		System.out.println(ds.payFee(tamt));
		System.out.println("\n");
		tamt = 30000;
		Hosteller hstl = new Hosteller(3,"virat kohli",25000,8000);
		System.out.println(hstl.displayDetails());
		System.out.println( hstl.payFee(tamt));		
	}

}
