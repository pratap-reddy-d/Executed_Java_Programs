package com.javapgr.stdu;

public class Hosteller extends Student{

	double hostelFee;

	public Hosteller(int studentId, String name, double examFee,double hostelFee) {
		super(name,studentId, examFee);
		this.hostelFee = hostelFee;
	}
	
	public String displayDetails() {
		
		return "Hosteller [hostelFee=" + hostelFee + ", name=" + name + ", studentId=" + studentId + ", examFee="
				+ examFee + "]";
	}
	
	public String payFee(double tamt) {
		
		double t =  hostelFee+examFee;
		String n = null;
		if(tamt == t) {
			n = "All Fees are clear";
		}
		else if(tamt < t) {
			t = tamt - t;
			n = "Remaining amount to pay is: "+t;
		}
		else {
			t = tamt - t;
			n = "Extra Reamining balance is:"+t;
		}
		return n;
	}
	
	
}
