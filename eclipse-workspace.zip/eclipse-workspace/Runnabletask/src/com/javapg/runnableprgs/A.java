package com.javapg.runnableprgs;

public class A implements Runnable{

	public void run() {
		System.out.println(Thread.currentThread().getName()+"A class");
		
	}
}
