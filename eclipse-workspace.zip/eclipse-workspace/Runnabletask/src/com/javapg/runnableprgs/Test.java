package com.javapg.runnableprgs;

public class Test {

	public static void main(String[] args) {
		new Thread(new B(),"T1").start();
	}
}
