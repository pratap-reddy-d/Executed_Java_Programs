package com.javapg.Threadex2;

public class MyRunnable7 implements Runnable{

	public void run() {
	System.out.println("MyRunnable: run()");
		
	}
	public void start()
	{
		System.out.println("MyRunnable: start()");
	}

}
