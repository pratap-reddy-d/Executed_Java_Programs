package com.javapg.Threadex2;

public class MyThread9 implements Runnable {

	String str;
	
	MyThread9(String str){
		this.str = str;
	}

	public void run() {
		for(int i=1; i<=10; i++)
		{
			System.out.println(str+ " : "+i);
			try
			{
				Thread.sleep(100);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}

}
