package com.javapg.collections_vector;

import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		
		Vector obj = new Vector(4,2);//initial capacity and incrementCapacity
		
		obj.addElement(new Integer(3));
		obj.addElement(new Integer(2));
		obj.addElement(new Integer(5));
		obj.insertElementAt(new Integer(8),2);
		
		System.out.println("Element at index");
		System.out.println(obj.elementAt(1));
		
		System.out.println("Vector class total capacity");
		System.out.println(obj.capacity());
		
		System.out.println("Vector elements size");
		System.out.println(obj.size());
		
		System.out.println("Remove all");
		obj.removeAll(obj);
		System.out.println(obj.isEmpty());
		
		System.out.println(obj);
		
		
	}
}
