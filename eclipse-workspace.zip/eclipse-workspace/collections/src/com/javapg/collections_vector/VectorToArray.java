package com.javapg.collections_vector;

import java.util.*;
public class VectorToArray {

	public static void main(String[] args) {
		
		Vector<Integer> v1 = new Vector<>();
		for(int i=0;i<5;i++) {
			v1.add(i+1);
		}
		
		System.out.println(v1);
		
		
		
		Object[] arr = v1.toArray();
		
		System.out.println(Arrays.toString(arr));
		
		
		
	}
}
