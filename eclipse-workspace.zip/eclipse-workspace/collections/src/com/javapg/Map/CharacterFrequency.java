package com.javapg.Map;

import java.util.HashMap;

public class CharacterFrequency {

	public static void main(String[] args) {
		
		String sample = "Hello, World!";
		
		HashMap <Character, Integer> m = new HashMap<Character, Integer>();
			
		
		
				
		for(Integer i=0;i<sample.length();i++) {
			
			Character ch = sample.charAt(i);
			
			if(Character.isLetterOrDigit(ch)) {
				ch = Character.toLowerCase(ch);
			}
			
			m.put(ch,m.getOrDefault(m, 0)+1);
	
		}
		
	System.out.println(m.entrySet());
		
		if (!m.isEmpty()) {
            System.out.println("Character frequencies in the string '" + sample + "':");
            for (HashMap.Entry<Character, Integer> entry : m.entrySet()) {
                System.out.println("'" + entry.getKey() + "' occurs " + entry.getValue() + " times");
            }  
		}
		
		
		
	}
	
	

}
