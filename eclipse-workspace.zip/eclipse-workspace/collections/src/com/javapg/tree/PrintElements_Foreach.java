package com.javapg.tree;

import java.util.*;

record mapping(String k,String v) {
	
}

public class PrintElements_Foreach {

	
	
	public static void main(String[] args) {
		
		
		LinkedList <String> map = new LinkedList<>();
		
		map.add("2234");
		map.add("ityui");
		map.add("2234");
		map.add("ityui");
		
	System.out.println();
	
	map.forEach(System.out::println);
	}
}
