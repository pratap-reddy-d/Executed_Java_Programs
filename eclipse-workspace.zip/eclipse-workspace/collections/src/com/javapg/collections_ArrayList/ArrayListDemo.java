package com.javapg.collections_ArrayList;

import java.util.ArrayList;
public class ArrayListDemo {

	public static void main(String[] args) {
		
//		ArrayList obj1 = new ArrayList();
//		ArrayList obj2 = new ArrayList();
//		
//		obj1.add("A");
//		obj1.add("B");
//		obj2.add("A");
//		obj2.add(1,"B");
//		System.out.println(obj1.equals(obj2)); // checks objects returns boolean
		
		ArrayList<Integer> obj3 = new ArrayList<>();
//		obj3.add(null);
//		obj3.add(0,"A");
//		obj3.add(null);
//		obj3.add(2,"B");
//		obj3.add("20");
//		obj3.add(1,"c");
//		
//		System.out.println(obj3);
		
		obj3.add(12);
		obj3.add(16);
		obj3.add(34);
		obj3.add(78);
		obj3.remove(Integer.valueOf(16)); // removes 12 value
//		 System.out.println(obj3); // int not type of String arrayList
		
//		obj3.add('a');
//		obj3.add('b'); //char not type of String arrayList
//		obj3.add('c');
//		obj3.add('d');
//		obj3.remove('c');
		 System.out.println(obj3);
		
		
		

	}

}
