package com.javapg.absconstructor;

public class S {

	public static void main(String[] args) {
		
	//	Sample s = new Sample(2);
		
	}
}
