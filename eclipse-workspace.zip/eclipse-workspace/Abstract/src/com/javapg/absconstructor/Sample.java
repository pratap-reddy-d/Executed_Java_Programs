package com.javapg.absconstructor;

abstract public class Sample {

	int a ;
	public Sample(int a){
		this.a = a;
	}
}
