package com.javapg.advancearithmetic;

public class TextPost implements Post {

	int likes;
	String textContent;
	
	
	public TextPost(String textContent) {
		super();
		this.likes = 0;
		if(textContent != null)
			this.textContent = textContent;
		else System.err.println("Error: Text content cannot be empty.\r\n"
				+ "");
	}

	@Override
	public void publish() {
		System.out.println(textContent);
		
	}

	@Override
	public void like() {
		this.likes++;
	System.out.println("Post Liked! Total likes:"+likes);
		
	}

	public void getTextContent() {
		System.out.println(textContent+"| Likes:"+likes);
	}
}
