package com.javapg.advancearithmetic;

interface AdvancedArithmetic {

	abstract public int divisorSum();
}
