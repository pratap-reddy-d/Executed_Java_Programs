package com.javapg.advancearithmetic;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		MyCalculator mc = new MyCalculator(n);
		int n1 = mc.divisorSum();
		if(n>0)
		System.out.println(n1);
			sc.close();
	}

}
