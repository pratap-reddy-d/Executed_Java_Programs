package com.javapg.advancearithmetic;

import java.util.Scanner;

public class PostTester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the text");
		String str = sc.next();
		TextPost tp = new TextPost(str);
		
		tp.publish();
		for(int i=0;i<5;i++) {
			tp.like();
		}
		tp.getTextContent();
		sc.close();
	}
}
