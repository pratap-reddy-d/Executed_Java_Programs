package com.shape.javaprg;

public class Circle extends Shape{

	double radius;
	
	
	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	@Override
	double getArea() {
		
		double area = 3.14*radius*radius;
		return area;
	}

	@Override
	void printDetails() {
		System.out.println("Type = Circle");
		System.out.println("Radius = "+ radius);
		System.out.println("Area = "+getArea());
	}

}
