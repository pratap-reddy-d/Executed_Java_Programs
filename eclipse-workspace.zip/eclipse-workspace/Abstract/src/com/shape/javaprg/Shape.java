package com.shape.javaprg;

abstract class Shape {

	abstract double getArea();
	abstract void printDetails();
}

