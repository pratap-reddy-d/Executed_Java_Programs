package Student;

abstract public class Student {

	protected String studentName;
	protected String studentClass;
	protected static int totalNoOfStudents ;
	
	public Student() {
		
	}
	
	static {
		totalNoOfStudents = 12;
	}
	
	public Student(String studentName, String studentClass) {
		super();
		this.studentName = studentName;
		this.studentClass = studentClass;
	}

	abstract public int getPercentage();
	
	public static int getTotalNoStudents() {;
	
	return 0;
	}
	
}
