package com.javapg.ArmstrongNumber;

import java.util.Scanner;

/*
 * whole number count multiplied with individual number
 * 
 * Armstrong from 0 to 1000
 */


public class ArmstrongNumber {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	//	System.out.println("Enter the number: ");
	//	int n = sc.nextInt();
		
		for(int i=1;i<=1000;i++) {
			ArmstrongNumber.Armstrong(i);
		}
		
	}

	public static void Armstrong(int num) {
		
		int n1 = num;
		double sum=0;
		double count = Math.ceil(Math.log10(n1));
		
		for(int i=1;i<=count;i++,n1/=10) {
			int n2 = n1%10;
			sum = sum+Math.pow(n2, count);
		}
		if(sum==num)
		System.out.println((int)sum);		
		
	}
}
