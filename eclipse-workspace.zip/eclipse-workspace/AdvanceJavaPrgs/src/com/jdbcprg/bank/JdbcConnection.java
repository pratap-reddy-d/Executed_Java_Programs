package com.jdbcprg.bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;
public class JdbcConnection {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		try(sc;){
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","system");
			
			PreparedStatement ps1 = con.prepareStatement("select * from Bank70");
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
