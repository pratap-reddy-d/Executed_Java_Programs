package com.javaprg.StreamMethodsStudent;

import java.util.stream.Stream;

public class FilterNames {

	public static void main(String[] args) {
		
		Stream<String> names = Stream.of("Toby", "Anna", "Leroy", "Alex");
		
		names.filter(name -> name.length() == 4).sorted().limit(2).forEach(System.out::println);
	}
}
//5 que 30-01-2025