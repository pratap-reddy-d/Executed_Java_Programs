package com.emp.trie;

import java.util.Scanner;

public class StudentElc {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Name:");
		String name = sc.nextLine();
		
		System.out.println("Enter the number:");
		int number = sc.nextInt();
		
		System.out.println("");
		StudentBlc.setData(name, number);
		StudentBlc.getData();
		
		sc.close();
		
	}

}
