package com.emp.trie;

public class StudentBlc {

	public static void setData(String name, int number) {
		System.out.println("Name is: "+name+"\n Number is: "+number);
	}
	
	public static void getData() {
		System.out.println("above is Student details!");
	}
}
