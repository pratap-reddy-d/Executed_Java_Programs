package com.emp.trie;

public class Empty {
	public static void y(int x) {
		 System.out.println("royale");
	}

}

class Max{
	public static void z(int q) {
		System.out.println("Mandate");
	}
	
}