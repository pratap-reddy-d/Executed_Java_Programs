package com.demo12pro;


public class InstanceBlockDemo1 
{
	public int madd(int n1,int n2) {
		return n1+n2;
	}
	public static int msub(int n1,int n2) {
		return n1-n2;
	}
	public int mmul(int n1,int n2) {
		return n1+n2;
	}
	public static void main(String[] args) 
	{
		InstanceBlockDemo1 t = new InstanceBlockDemo1();
		
		System.out.println(msub(3,2));
		System.out.println(t.madd(2, 1));
		System.out.println(t.msub(2, 1));
	}

}