package com.demo12pro;

@FunctionalInterface
interface Cube
{
	int cube(int b);
}
public class Man {
	
	public static void main(String[] args) {
		int a = 21;
		
		Cube cube = b -> b*b*b;
		System.out.println(cube.cube(a));
	}
}