package com.demo12pro;

import java.util.Scanner;

public class IntrestClaculator {

	public static void intrest(float p,int t,float r) {
		
	float result =	(p*t*r)/100;
	
	System.out.println("Intrest is: "+result);
	};
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Principle amount:");
		float amt = sc.nextFloat();
		
		System.out.println("Enter Time in months:");
		int year = sc.nextInt();
		
		System.out.println("Enter Rate of intreset:");
		float rateOfintreset = sc.nextFloat();
		
		intrest(amt,year,rateOfintreset);
		
		sc.close();
		
	}
}
