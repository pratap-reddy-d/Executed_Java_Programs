package com.javapg.educourseenrolsystem;

public class EducationInstituteApp {

	public static void main(String[] args) {
		
	//	Course course[] = {"Mathematics","Science","English"};
		int[] fee = {1000,1200,900};
		
		
		String o1 = "Special discount: Get 20% off on all courses!";
		String o2 = "Limited time offer: Enroll in any two courses and get one course free!";
		
		Offer o = new Offer(o1); 
		Offer oa = new Offer(o2);
		
		Student virat = new Student(o2, null);
		
		Student dhoni = new Student(o2, null);
		
		Thread t = new Thread() {
			
		};
		
		
	}
}

