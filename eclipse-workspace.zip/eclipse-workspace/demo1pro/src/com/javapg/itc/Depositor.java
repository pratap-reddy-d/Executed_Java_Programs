package com.javapg.itc;

public class Depositor extends Thread {

	private Account account;
	
	public Depositor(Account account) {
		super();
		this.account = account;
	}

	@Override
	public void run() {
		int[] deposits = {1000,400,900};
		
		for(int d : deposits) {
			try {
				account.deposit(d);
				Thread.sleep(1000);
			}
			catch(InterruptedException e) {
				System.out.println(e);
			}
			
		}
	}
	
}
