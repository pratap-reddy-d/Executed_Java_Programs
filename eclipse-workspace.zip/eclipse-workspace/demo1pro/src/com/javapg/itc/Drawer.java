package com.javapg.itc;

public class Drawer extends Thread {

	private Account account;
	
	public Drawer(Account account) {
		super();
		this.account = account;
	}

	@Override
	public void run() {
		
		int[] withdraw = {100,790,765};
		
		for(int x: withdraw) {
			
			try {
				Thread.sleep(1000);
			}
			catch(InterruptedException e) {
				System.out.println(e);
			}
			
			account.withdraw(x);
			
		}
	}
	
}
